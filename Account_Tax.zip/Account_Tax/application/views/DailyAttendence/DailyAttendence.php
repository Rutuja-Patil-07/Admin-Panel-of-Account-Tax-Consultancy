
        <!-- =============== Left side End ================-->
        <div class="main-content-wrap sidenav-open d-flex flex-column">
            <!-- ============ Body content start ============= -->
            <div class="main-content">
                
                <!-- <div class="separator-breadcrumb border-top"></div> -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="card mb-4">
                            <div class="card-body">
                            <div class="breadcrumb">
                    <h1>Daily Attendence</h1>
                   
                </div>
                                <form role="form" id="Form" action="" method="post">
                                    <div class="row">
                                    <div class="col-md-2 form-group mb-3 ml-2">
                                           <label for="name">Employee Name:</label>
                                           <select class="form-control" name="name" id="name">
                                                <option value="India">Sumit</option>
                                                <option value="America">Rutuja</option>
                                                <option value="India">Shravani</option>
                                                <option value="America">Nilambari</option>
                                               
                                            </select>                                        </div>
                                        <div class="col-md-2 form-group mb-3 ml-2">
                                           <label for="attendence">Attendence Date:</label>
                                           <input type="date" class="form-control" id="attendence" placeholder="Enter AttendenceDate..." name="attendence" value="<?php echo date('Y-m-d'); ?>">                                        
                                        </div>
                                       <div class="col-md-1 mt-4 mb-3 text-right">
                                         <button class="btn btn-success" type="button" name="btn_search" id="btn_search"><i class="nav-icon fa-regular fa-circle-check"></i> Search</button>
                                       </div>
                                    </div>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;&nbsp;

                                    

                                   

                                    <div class="table-responsive">
                                    <table class="display table table-striped table-bordered" id="example" style="width:100%">
                                        <thead>
                                            <tr class="border">
                                                <th>Sr No.</th>
                                                <th>Employee Name</th>
                                                <th>Attendence Date</th>
                                                <th>Attendence</th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                                <td>1</td>
                                                <td>Sumit</td>
                                                <td>12/01/2023</td>
                                                <td>Present</td>
                                                
                                            </tr>

                                            <tr>
                                                <td>2</td>
                                                <td>Rutuja</td>
                                                <td>12/01/2023</td>
                                                <td>Absent</td>
                                                
                                            </tr>

                                            <tr>
                                                <td>3</td>
                                                <td>Shravani</td>
                                                <td>12/01/2023</td>
                                                <td>Present</td>
                                                
                                            </tr>

                                            <tr>
                                                <td>4</td>
                                                <td>Nilambari</td>
                                                <td>12/01/2023</td>
                                                <td>Half Day</td>
                                                
                                            </tr>

                                            <tr>
                                                <td>5</td>
                                                <td>Yugandhara</td>
                                                <td>12/01/2023</td>
                                                <td>Absent</td>
                                                
                                            </tr>
                                        </tbody>
                                        
                                    </table>
                                </div>
                                <div class="col-md-12 text-right">
                                      <button class="btn btn-outline-info" type="button" name="submit" id="submit"><i class="fa-solid fa-check"></i>&nbsp;submit</button>

                                     <button class="btn btn-outline-warning " type="button" name="edit" id="edit"><i class="fa-solid fa-user-pen"></i>&nbsp;Edit</button>
                                        </div>
                                          

                                        
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
</div>
                  

<script  src="<?php echo base_url('web_resources');?>/dist/js/jquery.min.js"></script>          
<script  src="<?php echo base_url('web_resources');?>/dist/js/controllers/Familytypecreate.js"></script>
                   
                       
               
            