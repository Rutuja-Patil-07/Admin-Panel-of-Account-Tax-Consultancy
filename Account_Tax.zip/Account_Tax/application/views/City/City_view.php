
        <!-- =============== Left side End ================-->
        <div class="main-content-wrap sidenav-open d-flex flex-column">
            <!-- ============ Body content start ============= -->
            <div class="main-content">
                
                <!-- <div class="separator-breadcrumb border-top"></div> -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="card mb-4">
                            <div class="card-body">
                            <div class="breadcrumb">
                    <h1>City</h1>
                
                </div>
                                <form role="form" id="Form" action="" method="post">
                                    <div class="row">

                              
                                      
                                    <div class="col-md-3 form-group mb-3">
                                            <label for="picker1">State</label>
                                            <select class="form-control" name="state" id="state">
                                                <option value="Maharashtra1">Maharashtra</option>
                                                <option value="Amaravati">Amaravati</option>
                                                <option value="Assam">Assam</option>
                                                <option value="Gujarat">Gujarat</option>
                                                <option value="Goa">Goa</option>
                                                <option value="Kerala">Kerala</option>
                                                <option value="Rajasthan">Rajasthan</option>
                                                <option value="Tamil Nadu">Tamil Nadu</option>

                                              
                                            </select>
                                        </div>


                                        <div class="col-md-3 form-group mb-3">
                                            <label for="firstName1">City name</label>
                                            <input class="form-control" id="city_name" type="text" name="city_name" value="" />
                                        </div>
                                       
                                      
                                     
                                        
                                        
                                        
                                     
                                        <div class="col-md-12 text-right">
                                    <button class="btn btn-outline-info" type="button" name="btn_save" id="btn_save"><i class="fa-solid fa-check"></i>&nbsp;submit</button>

                                     <a href="<?=base_url() ?>City/index"> <button class="btn btn-outline-warning " type="button" name="edit" id="edit"><i class="fa-solid fa-user-pen"></i>&nbsp;Edit</button></a>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
</div>
                  

<script  src="<?php echo base_url('web_resources');?>/dist/js/jquery.min.js"></script>          
<script  src="<?php echo base_url('web_resources');?>/dist/js/controllers/city.js"></script>
                   
                       
               
            