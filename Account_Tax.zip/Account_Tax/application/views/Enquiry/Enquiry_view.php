
        <!-- =============== Left side End ================-->
        <div class="main-content-wrap sidenav-open d-flex flex-column">
            <!-- ============ Body content start ============= -->
            <div class="main-content">
                
                <!-- <div class="separator-breadcrumb border-top"></div> -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="card mb-4">
                            <div class="card-body">
                            <div class="breadcrumb">
                    <h1>Enquiry</h1>
                   
                </div>

                                <form role="form" id="Form" action="" method="post">
                                    <div class="row mt-3">
                                        <div class="col-md-3 form-group mb-3">
                                            <label for="firstName1">Enquiry Name</label>
                                            <input class="form-control" id="enquiry_name" type="text"  name="enquiry_name" value="" />
                                        </div>
                                        <div class="col-md-2 form-group mb-3">
                                            <label for="firstName1">Enquiry Time</label>
                                            <input class="form-control" id="time" type="time" name="time" value="" />
                                        </div>

                                        <div class="col-md-2 form-group mb-3">
                                            <label for="firstName1"> Date</label>
                                            <input class="form-control" id="date" type="date"  name="date" value="" />
                                        </div>
                                        <div class="col-md-2 form-group mb-3">
                                            <label for="name">Reference Type</label>
                                            <select class="form-control" name="ref_type" id="ref_type">
                                            <option value="CEO">CEO</option>
                                                <option value="PA">PA</option>
                                                <option value="SENIOR">SENIOR</option>
                                                <option value="JUNIOR">JUNIOR</option>

                                            </select>                                        
                                        </div>
                                        <div class="col-md-3 form-group mb-3">
                                            <label for="firstName1">Reference Name</label>
                                            <input class="form-control" id="ref_name" type="text"  name="ref_name" value="" />
                                        </div>

                                    </div>
                                    <div class="row">              
                                        <div class="col-md-2 form-group mb-3">
                                            <label for="name">Reference No</label>
                                            <input class="form-control" id="ref_no" type="number"  name="ref_no" value="" />
                                        </div>
                                        <div class="col-md-4 form-group mb-3">
                                            <label for="firstName1">Enquiry Reason</label>
                                            <textarea class="form-control" rows="2" id="enq_reason" name="enq_reason"></textarea>

                                        </div>
                                     </div> 
                                      
                                      
                                     <div class="col-md-12 text-right">
                                     <button class="btn btn-outline-info" type="button" name="btn_save" id="btn_save"><i class="fa-solid fa-check"></i>&nbsp;submit</button>

                                     <a href="<?=base_url() ?>Enquiry/index"> <button class="btn btn-outline-warning " type="button" name="edit" id="edit"><i class="fa-solid fa-user-pen"></i>&nbsp;Edit</button></a>
                                        </div>
                                </form>
                            </div>
                        </div>
                </div>
</div>
                  

<script  src="<?php echo base_url('web_resources');?>/dist/js/jquery.min.js"></script>          
<script  src="<?php echo base_url('web_resources');?>/dist/js/controllers/enquiry.js"></script>
                   
<script>
     var date = new Date();
var day = date.getDate();
var month = date.getMonth() + 1;
var year = date.getFullYear();

if (month < 10) month = "0" + month;
if (day < 10) day = "0" + day;

var today = year + "-" + month + "-" + day;       
document.getElementById("date1").value = today;
document.getElementById("date2").value = today;

</script>                       
               
            