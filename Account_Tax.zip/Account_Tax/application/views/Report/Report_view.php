  
        <!-- =============== Left side End ================-->
        <div class="main-content-wrap sidenav-open d-flex flex-column">
            <!-- ============ Body content start ============= -->
            <div class="main-content">
                
                <!-- <div class="separator-breadcrumb border-top"></div> -->
                
               
                
   
                <div class="row">   
                 
                    <div class="col-md-12">

                        <div class="card mb-4 p-3">
                            <div class="card-body">
                            <div class="breadcrumb">
                          <h1>Report</h1>
                        </div>
                </div>     
                <div class="row">  
                        <div class="col-lg-9 "></div>
                        <div class="form-group col-md-3 d-flex">
                                            <label for="firstName1">Form:&emsp;</label>
                                            <input class="form-control" id="from" type="text"  name="from" value="" />&emsp;
                                            <label for="firstName1">To:&emsp;</label>
                                            <input class="form-control" id="to" type="text"  name="to" value="" />
                                        </div> 

                                        </div>  
                                                      
                                <div class="table-responsive">
                                <div class="table-responsive">
                                    <table class="display table table-striped table-bordered" id="example" style="width:100%">
                                    <thead>
                                            <tr>
                                                <th>Sr.No</th>
                                                <th>Employee Name</th>
                                                <th>Date</th>
                                                <th>Whome to Call</th>                                            
                                                <th>Contact No</th>
                                                <th>Reason</th>

                                            </tr>
                                        </thead>
                                        <tbody>
                                        <!-- <?php 
                                 $i=0;
                                foreach($data as $rw=>$value){
                                 echo "<tr>";
                               
                                
                                echo "<td>".$value->srno."</td>";
                                echo "<td>".$value->employeename."</td>";
                                echo "<td>".$value->date."</td>";
                                echo "<td>".$value->whometocall."</td>";$i++;
                                echo "<td>".$value->contactno."</td>";
                                echo "<td>".$value->Reason."</td>";
                                
             
                              ;
                                 echo "</tr>";                        
                             }
                             ?>  -->
                             <tr>
                             <td>01</td>                             
                                <td>Sumit</td>
                                <td>10/12/22</td>
                                <td>Rushi</td>
                                <td>7378703032</td>
                                <td>Personal</td>
                                
                             </tr>
                                          
                                        </tbody>
                                        
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
</div> 
                            </div>
                            </div>
                  

<script  src="<?php echo base_url(); ?>web_resources/dist/js/jquery.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>

    <script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script type="text/javascript" src=https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js></script> 
<script type="text/javascript" src="https://cdn.datatables.net/buttons/2.3.2/js/dataTables.buttons.min.js"></script>
 <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script> 
 <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script> 
 <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script> 
 <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.3.2/js/buttons.html5.min.js"></script> 
 <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.3.2/js/buttons.print.min.js"></script>
<script>
$(document).ready(function() {
    $('#example').DataTable( { 
            
         responsive: true,
         dom: 'Bfrtip',
         dom: 'lBfrtip',
         buttons: [
           { extend: 'copy',text:'<img src="https://img.icons8.com/color/2x/copyright--v1.png" style="width:25px;">', className: 'buttons-copy' },
           { extend: 'csv',text: '<img src="https://img.icons8.com/color/2x/csv.png" style="width:25px;">', className: 'buttons-csv' },
           { extend: 'excel',text: '<img src="https://img.icons8.com/color/512/ms-excel.png" style="width:25px;">', className: 'buttons-excel' },
           { extend: 'pdf',text: '<img src="https://img.icons8.com/color/512/pdf-2--v1.png" style="width:25px;">', className: 'buttons-pdf' },
           { extend: 'print',text: '<img src="https://img.icons8.com/3d-fluency/2x/print.png" style="width:25px;">', className: 'buttons-print' }
                ],
            initComplete: function() {
            var btns = $('.dt-buttons');
            btns.removeClass('dt-buttons');
        },
        
    } );
    
    
} );






</script>
                   
                       
               
