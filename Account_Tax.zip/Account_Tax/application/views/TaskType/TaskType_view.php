<!-- =============== Left side End ================-->
    <div class="main-content-wrap sidenav-open d-flex flex-column">
        <!-- ============ Body content start ============= -->
            <div class="main-content">
                <div class="breadcrumb">
                    <h1>Task Type</h1>
                    <!-- <ul>
                        <li><a href="href.html">Form</a></li>
                        <li>Basic</li>
                    </ul> -->
                </div>
                <div class="separator-breadcrumb border-top"></div>
                <form role="form" id="Form" action="" method="post">
                    <div class="row">
                        <div class="col-12">
                            <div class="card p-3">
                                <div class="card-body">
                                    
                                    <label class="h4">Task Type</label>
                                    <br><div class="vh col-12"></div>
                                    <div class="row">
                                        <div class="col-5 h6 form-group"><br>
                                            <label>Task Type<span class="text-danger">*</span></label><br>
                                            <input class="form-control" type="text" name="tasktype" id="tasktype" >
                                        </div>
                                    </div>
                                    <div class="col-md-12 text-right">
                                     <a href="<?=base_url() ?>"> <button class="btn btn-outline-info" type="button" name="submit" id="submit"><i class="fa-solid fa-check"></i>&nbsp;submit</button></a>

                                     <a href="<?=base_url() ?>TaskType/index"> <button class="btn btn-outline-warning " type="button" name="edit" id="edit"><i class="fa-solid fa-user-pen"></i>&nbsp;Edit</button></a>
                                        </div>
                                </div>
                            </div>  
                        </div>
                    </form>
                </div>

   


                  

</script>
<script  src="<?php echo base_url('web_resources');?>/dist/js/jquery.min.js"></script>          
<script  src="<?php echo base_url('web_resources');?>/dist/js/controllers/StudentCreate.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
                   
                       
               
            