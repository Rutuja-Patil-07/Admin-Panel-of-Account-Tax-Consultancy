<link rel="stylesheet" href="https://cdn.datatables.net/1.13.1/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.3.2/css/buttons.dataTables.min.css">
<!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.0/css/bootstrap.min.css"> -->
  <!-- <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" /> -->
<link rel="stylesheet" href="Assets/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.1/css/dataTables.bootstrap3.min.css">
<style>
.fa-file-excel:before {
    content: "\f1c1";
    color: #1d6f42;
    font-size:19px;
}
.fa-file-pdf:before {
    content: "\f1c1";
    color: #f40f02;
    font-size:19px;
}
.fa-file-csv:before {
    content: "\f6dd";
    color:teal;
    font-size:19px;
}
.fa-copy:before, .fa-files-o:before {
    content: "\f0c5";
    color:rgba(86, 141, 229, 1);
    font-size:19px;
}.fa-print:before {
    content: "\f02f";
    color: black;
    font-size:19px;
}
.animtxt:hover{
  transform: scale(1.2);
}
.animimg:hover{
  transform: scale(1.05);
}

.buttons-excel {
  border:none;
  /* background-color:green; */
  color:#black;
  margin:0 auto;
  /* border:1px solid white; */
}
.buttons-copy {
 border:none;
 /* background-color:#BBDEF9; */
  color:white;
  margin:0 5;
  margin-left:25px;
  /* border:1px solid white; */
}
.buttons-pdf {
  border:none;
  /* background-color:#f40f02; */
  color:white;
  margin:0 auto;
  /* border:1px solid white; */
}
.buttons-csv {
  /* background-color: #445AD3; */
  border:none;
  color:white;
  /* border:1px solid white; */
  margin:0 5;
}
.buttons-excel {
  border:none;
  /* background-color: #1d6f42 ; */
  color:white;
  margin:0 5;
  /* border:1px solid white; */
}
.buttons-print {
  border:none;
  /* background-color:#36454F; */
  color:white;
  margin:0 5;
  /* border:1px solid white; */
}
[type=button]:not(:disabled), [type=reset]:not(:disabled), [type=submit]:not(:disabled), button:not(:disabled) {
    cursor: pointer;
    background-color: white;
}
.table.dataTable.display>tbody>tr.odd>.sorting_1, table.dataTable.order-column.stripe>tbody>tr.odd>.sorting_1 {
  box-shadow:inset 0 0 0 9999px rgb(0 0 0 / 2%)
}



.breadcrumb {
  background: transparent;
  justify-content: center;
  align-items: center;
  margin: -3px 0 1.25rem;

 }
.breadcrumb img{
  margin-top: -70px;
  margin-bottom: -45px;
  
}

  .breadcrumb h4 {
    margin-left:2px;
    margin-top: -20px;
    position: absolute;
    color: var(--white);
    text-align:center;
    font-family: Frozen;
    font-weight: 600;
    font-size: 1.4rem;
    line-height: 1;
     }
     .card {
    border-radius: 10px;
    box-shadow: 0 4px 20px 1px rgb(0 0 0 / 6%), 0 1px 4px rgb(0 0 0 / 8%);
    border: 0;
    margin: -16px;
}

  


a {
  color: #73685d;
}
  
 @media all and (max-width: 768px) {
    
  table, thead, tbody, th, td, tr {
    display: block;
  }
  
}
    </style>
<body>
        <!-- =============== Left side End ================-->
        <div class="main-content-wrap sidenav-open d-flex flex-column">
            <!-- ============ Body content start ============= -->
            <div class="main-content">
                
                <!-- <div class="separator-breadcrumb border-top"></div> -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="card mb-2">
                            <div class="card-body">
                            <div class="breadcrumb">
                    <h1>Edit Employee</h1><br>
                </div>
                                <div class="table-responsive">
                                   <table class="display table table-striped table-bordered" id="example" style="width:100%">
                                        <thead>
                                            <tr>
                                                <th>Action</th>
                                                <th>Employee Name</th>
                                                <th>Mobile No</th>
                                                <th>Address</th>
                                                <th>Department</th>
                                                <th>Branch</th> 
                                                <th>Qualification</th>
                                                <th>Employee Type</th> 
                                                <th>Email</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr id="row1">
                                                 <td><i class="far fa-edit fa-lg"style="color:#1977D3;"></i><a href="<?=base_url('Employee/create');?>" data-mdb-toggle="tooltip" title="edit">&nbsp;Edit</a></td>
                                                <td>Nilambari Kothavale</td>
                                                <td>1234567890</td>
                                                <td>Kolhapur</td>
                                                <td>Development</td>
                                                <td>Pune</td>
                                                <td>MCA</td>
                                                <td>....</td>
                                                <td>nilambari@gmail.com</td>
                                            </tr>     
                                        </tbody>    
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
</div>
 
                              

<script  src="<?php echo base_url(); ?>web_resources/dist/js/jquery.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>

    <script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script type="text/javascript" src=https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js></script> 
<script type="text/javascript" src="https://cdn.datatables.net/buttons/2.3.2/js/dataTables.buttons.min.js"></script>
 <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script> 
 <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script> 
 <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script> 
 <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.3.2/js/buttons.html5.min.js"></script> 
 <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.3.2/js/buttons.print.min.js"></script>
<script>
$(document).ready(function() {
    $('#example').DataTable( { 
            
         responsive: true,
         dom: 'Bfrtip',
         dom: 'lBfrtip',
         buttons: [
            { extend: 'copy',text:'<img src="https://img.icons8.com/color/2x/copyright--v1.png" style="width:25px;">', className: 'buttons-copy' },
           { extend: 'csv',text: '<img src="https://img.icons8.com/color/2x/csv.png" style="width:25px;">', className: 'buttons-csv' },
           { extend: 'excel',text: '<img src="https://img.icons8.com/color/512/ms-excel.png" style="width:25px;">', className: 'buttons-excel' },
           { extend: 'pdf',text: '<img src="https://img.icons8.com/color/512/pdf-2--v1.png" style="width:25px;">', className: 'buttons-pdf' },
           { extend: 'print',text: '<img src="https://img.icons8.com/3d-fluency/2x/print.png" style="width:25px;">', className: 'buttons-print' }
                ],
            initComplete: function() {
            var btns = $('.dt-button');
            btns.removeClass('dt-button');
        },
        
    } );
    
} );

</script>
</html>