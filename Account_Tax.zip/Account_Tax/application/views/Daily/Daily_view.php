
        <!-- =============== Left side End ================-->
        <div class="main-content-wrap sidenav-open d-flex flex-column">
            <!-- ============ Body content start ============= -->
            <div class="main-content">
                
                <!-- <div class="separator-breadcrumb border-top"></div> -->
                <div class="row">
                    <div class="col-md-12">
                    <div class="card mb-4">
                            <div class="card-body">
                    <div class="breadcrumb">
                    <h1>Daily Log</h1>
                   
                </div>
                                <form role="form" id="Form" action="" method="post">
                                    <div class="row">
                                    <div class="col-4 form-group mb-3">
                                            <label for="picker1">Employee  Name</label>
                                            <select class="form-control" name="tagsname" id="tagname">
                                            <option>--Employee Name--</option>    
                                            <option value="1">tag1</option>
                                                <option value="2">tag2</option>
                                                <option value="3">tag3</option>
                                            </select>
                                        </div>
                                        <div class="col-4 form-group mb-3">
                                            <label for="desc">Job Description</label>
                                            <textarea class="form-control" name="description" id="desc" cols="" rows="2" placeholder="Enter job description"></textarea> 
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-4 form-group mb-3">
                                            <label for="desc">Work</label>
                                            <textarea class="form-control" name="description" id="desc" cols="" rows="2" placeholder="Enter work"></textarea> 
                                        </div>
                                        <div class=" col-4 form-group mb-3">
                                            <label for="time">Expected time</label>
                                            <input class="form-control" id="time" type="time" name="time" value="<?php echo date('H-m-s'); ?>" />
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-4 form-group mb-3">
                                            <label for="desc">Subwork</label>
                                            <textarea class="form-control" name="description" id="desc" cols="" rows="2" placeholder="Enter subwork"></textarea> 
                                        </div>
                                        <div class=" col-4 form-group mb-3">
                                            <label for="date">Start Date</label>
                                            <input class="form-control" id="date" type="date" name="date" value="<?php echo date('Y-m-d'); ?>" />
                                        </div>
                                    </div>
                                    <div class="row">
                                    <div class="col-4 form-group mb-3">
                                            <label for="desc">Task Assigned By</label>
                                            <textarea class="form-control" name="description" id="desc" cols="" rows="2" placeholder="Enter task assigned"></textarea> 
                                        </div>
                                        <div class="col-4 form-group mb-3">
                                            <label for="picker1">Status</label>
                                            <select class="form-control" name="tagsname" id="tagname">
                                            <option>--Select--</option>    
                                            <option value="1">tag1</option>
                                                <option value="2">tag2</option>
                                                <option value="3">tag3</option>
                                            </select>
                                        </div>
                                        
                                    </div>
                                    <div class="row">
                                    <div class=" col-4 form-group mb-3">
                                            <label for="date">Start Date</label>
                                            <input class="form-control" id="date" type="date" name="date" value="<?php echo date('Y-m-d'); ?>" />
                                        </div>
                                    <div class=" col-4 form-group mb-3">
                                            <label for="time">Actual time</label>
                                            <input class="form-control" id="time" type="time" name="time" value="<?php echo date('H-m-s'); ?>" />
                                        </div>
                                     </div>
                                     <div class="row">
                                     <div class=" col-4 form-group mb-3">
                                            <label for="date">End Date</label>
                                            <input class="form-control" id="date" type="date" name="date" value="<?php echo date('Y-m-d'); ?>" />
                                        </div>
                                        <div class="col-4 form-group mb-3">
                                            <label for="desc">Priority</label>
                                            <textarea class="form-control" name="description" id="desc" cols="" rows="2" placeholder="Enter priority"></textarea> 
                                        </div>

                                     </div>
                                     <div class="row">
                                     <div class="col-4 form-group mb-3">
                                            <label for="desc">Remark by Reporting Person</label>
                                            <textarea class="form-control" name="description" id="desc" cols="" rows="2" placeholder="Enter remark by reporting person"></textarea> 
                                        </div>
                                        <div class="col-4 form-group mb-3">
                                            <label for="desc">Remark by Employee</label>
                                            <textarea class="form-control" name="description" id="desc" cols="" rows="2" placeholder="Enter remark by employee"></textarea> 
                                        </div>
                                     </div>

                                    
                                        
                                     <div class="col-md-12 text-right">
                                    <button class="btn btn-outline-info" type="button" name="btn_save" id="btn_save"><i class="fa-solid fa-check"></i>&nbsp;submit</button>

                                     <a href="<?=base_url() ?>"> <button class="btn btn-outline-warning " type="button" name="edit" id="edit"><i class="fa-solid fa-user-pen"></i>&nbsp;Edit</button></a>
                                        </div>
                                </form>
                    </div>
</div>
                  

<script  src="<?php echo base_url('web_resources');?>/dist/js/jquery.min.js"></script>          
<script  src="<?php echo base_url('web_resources');?>/dist/js/controllers/Branch_Create.js"></script>
                   
                       
               
<script>
    $('#Form').bind('keydown', function(event) {
    if (event.ctrlKey || event.metaKey) {
    switch (String.fromCharCode(event.which).toLowerCase()) {
    case 's':
    event.preventDefault();
    // alert('ctrl-s');
    saveperform();
    break;

    }
    $(function(){
    $("#branch_name").focus();
    });

    }
    });
</script>