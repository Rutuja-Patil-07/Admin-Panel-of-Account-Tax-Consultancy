
<style>
    

    .arrow{
      position: relative;
      width:300px;
      background: red
      height:40px;
      line-height: 40px;
      margin-bottom:30px; 
      text-align:center;
      font-size:20px;
      color:#fff;
    }
    
    .arrow-right:after{
        content: "";
        position: absolute;
        right: -20px;
        top: 0;
        border-top: 20px solid transparent;
        border-bottom: 20px solid transparent;
        border-left: 20px solid red; 
    }
    .abc:hover
    {
        transform:scale(1.05);
        box-shadow: 0 10px 20px rgba(0,0,0,.12),0 4px 8px rgba(0,0,0,.06);
    }
    
    
    </style>
            <!-- =============== Left side End ================-->
            <div class="main-content-wrap sidenav-open d-flex flex-column">
                <!-- ============ Body content start ============= -->
                <div class="main-content">
                    <div class="breadcrumb">
                        <h1> Dashboard</h1>
                    
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card mb-4">
                                <div class="card-body">
                                    <form role="form" id="Form" action="" method="post">
                                        <div class="row">
                                         <div class="col-md-3 form-group mb-3">
                                                <label for="picker1">Branch name</label>
                                                <select class="form-control" name="branchname">
                                                    <option value="1">India</option>
                                                    <option value="1">Chin</option>
                                                    <option value="1">Africa</option>
                                                    <option value="1">America</option>
                                                  
                                                </select>
                                            </div>
                                            <div class="col-md-3 form-group mb-3">
                                                <label for="">Startdate</label>
                                                <input class="form-control" type="date" name="startdate" id="startdate">
                                            </div>
                                            <div class="col-md-3 form-group mb-3">
                                                <label for="">Enddate</label>
                                                <input class="form-control" type="date" name="endtdate" id="enddate">
                                            </div>
                                            <div class="col-md-3 form-group mb-3">
                                            <img src="<?=base_url();?>Assets\images\search.png" id="userDropdown" alt="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="height:30px;margin-top:30px;">
                                            </div> 
    
                                           
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
    </div>
                     
                    <!-- <div class="separator-breadcrumb border-top"></div> -->
                    <div class="row">
                       
                       <div class="col-lg-4 col-md-6 col-sm-6">
                          
                             <div class="arrow arrow-right bg-danger  text-white" style="width:300px;"> Purchase Requestation</div>    
                              
                       </div>  
                   </div> 
                      
                       
                </div>
                    <div class="row">
                        <div class="col-lg-4 col-md-6 col-sm-6">
                            <div class="card card-icon-bg card-icon-bg-white o-hidden mb-4 abc">
                                <div class="card-body bg-warning text-center"><i class="fa-solid fa-calculator" style="color:white"></i>
                                    <div class="content">
                                        
                                        <h4 class="text-white mt-0 mb-1">Todays Count</h4>
                                        <lable class="text-white text-24 line-height-1 mb-1">0</lable>
                                        <p class="text-white text-14 mb-1">compared to last week</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-6">
                            <div class="card card-icon-bg card-icon-bg-white o-hidden mb-4 abc">
                                <div class="card-body bg-primary text-center"><i class="fa fa-eur" aria-hidden="true" style="color:white"></i>
    
                                    <div class="content">
                                    <h4 class="text-white mt-0 mb-1">Total Count</h4>
                                        <lable class="text-white text-24 line-height-1 mb-1">13</lable>
                                        <p class="text-white text-14 mb-1">compared to last week</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-6">
                            <div class="card card-icon-bg card-icon-bg-white o-hidden mb-4 abc">
                                <div class="card-body bg-success text-center"><i class="nav-icon fa fa-hourglass-half" aria-hidden="true" style="color:white"></i>
                                    <div class="content">
                                    <h4 class="text-white mt-0 mb-1">Pending Count</h4>
                                        <lable class="text-white text-24 line-height-1 mb-1">0</lable>
                                        <p class="text-white text-14 mb-1">compared to last week</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                       
                    </div>
                    <div class="row">
                       
                       <div class="col-lg-4 col-md-6 col-sm-6">
                          
                             <div class="arrow arrow-right bg-danger  text-white" style="width:300px;"> Request For Quotation</div>    
                              
                       </div>  
                   </div> 
    <div class=row>
                    <div class="card"></div>
                        <div class="col-lg-4 col-md-6 col-sm-6">
                            <div class="card card-icon-bg card-icon-bg-white o-hidden mb-4 abc">
                                <div class="card-body bg-warning text-center"><i class="fa-solid fa-calculator" style="color:white"></i>
                                    <div class="content">
                                        
                                        <h4 class="text-white mt-0 mb-1">Todays Count</h4>
                                        <lable class="text-white text-24 line-height-1 mb-1">0</lable>
                                        <p class="text-white text-14 mb-1">compared to last week</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-6">
                            <div class="card card-icon-bg card-icon-bg-white o-hidden mb-4 abc">
                                <div class="card-body bg-primary text-center"><i class="fa fa-eur" aria-hidden="true" style="color:white"></i>
    
                                    <div class="content">
                                    <h4 class="text-white mt-0 mb-1">Total Count</h4>
                                        <lable class="text-white text-24 line-height-1 mb-1">13</lable>
                                        <p class="text-white text-14 mb-1">compared to last week</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-6">
                            <div class="card card-icon-bg card-icon-bg-white o-hidden mb-4 abc">
                                <div class="card-body bg-success text-center"><i class="nav-icon fa fa-hourglass-half" aria-hidden="true" style="color:white"></i>
                                    <div class="content">
                                    <h4 class="text-white mt-0 mb-1">Pending Count</h4>
                                        <lable class="text-white text-24 line-height-1 mb-1">0</lable>
                                        <p class="text-white text-14 mb-1">compared to last week</p>
                                    </div>
                                </div>
                            </div>
                        </div>
    </div>     
    <div class="row">
                       
                       <div class="col-lg-4 col-md-6 col-sm-6">
                          
                             <div class="arrow arrow-right bg-danger  text-white" style="width:300px;">  Quotation</div>    
                              
                       </div>  
                   </div>        
    <div class=row>
                    <div class="card"></div>
                        <div class="col-lg-4 col-md-6 col-sm-6">
                            <div class="card card-icon-bg card-icon-bg-white o-hidden mb-4 abc">
                                <div class="card-body bg-warning text-center"><i class="fa-solid fa-calculator" style="color:white"></i>
                                    <div class="content">
                                        
                                        <h4 class="text-white mt-0 mb-1">Todays Count</h4>
                                        <lable class="text-white text-24 line-height-1 mb-1">0</lable>
                                        <p class="text-white text-14 mb-1">compared to last week</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-6">
                            <div class="card card-icon-bg card-icon-bg-white o-hidden mb-4 abc">
                                <div class="card-body bg-primary text-center"><i class="fa fa-eur" aria-hidden="true" style="color:white"></i>
    
                                    <div class="content">
                                    <h4 class="text-white mt-0 mb-1">Total Count</h4>
                                        <lable class="text-white text-24 line-height-1 mb-1">13</lable>
                                        <p class="text-white text-14 mb-1">compared to last week</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-6">
                            <div class="card card-icon-bg card-icon-bg-white o-hidden mb-4 abc">
                                <div class="card-body bg-success text-center"><i class="nav-icon fa fa-hourglass-half" aria-hidden="true" style="color:white"></i>
                                    <div class="content">
                                    <h4 class="text-white mt-0 mb-1">Pending Count</h4>
                                        <lable class="text-white text-24 line-height-1 mb-1">0</lable>
                                        <p class="text-white text-14 mb-1">compared to last week</p>
                                    </div>
                                </div>
                            </div>
                        </div>
    </div>
    <div class="row">
                       
                       <div class="col-lg-4 col-md-6 col-sm-6">
                          
                             <div class="arrow arrow-right bg-danger  text-white" style="width:300px;"> Purchase Order</div>    
                              
                       </div>  
                   </div>        
    <div class=row>
                    <div class="card"></div>
                        <div class="col-lg-4 col-md-6 col-sm-6">
                            <div class="card card-icon-bg card-icon-bg-white o-hidden mb-4 abc">
                                <div class="card-body bg-warning text-center"><i class="fa-solid fa-calculator" style="color:white"></i>
                                    <div class="content">
                                        
                                        <h4 class="text-white mt-0 mb-1">Todays Count</h4>
                                        <lable class="text-white text-24 line-height-1 mb-1">0</lable>
                                        <p class="text-white text-14 mb-1">compared to last week</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-6">
                            <div class="card card-icon-bg card-icon-bg-white o-hidden mb-4 abc">
                                <div class="card-body bg-primary text-center"><i class="fa fa-eur" aria-hidden="true" style="color:white"></i>
    
                                    <div class="content">
                                    <h4 class="text-white mt-0 mb-1">Total Count</h4>
                                        <lable class="text-white text-24 line-height-1 mb-1">13</lable>
                                        <p class="text-white text-14 mb-1">compared to last week</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-6">
                            <div class="card card-icon-bg card-icon-bg-white o-hidden mb-4 abc">
                                <div class="card-body bg-success text-center"><i class="nav-icon fa fa-hourglass-half" aria-hidden="true" style="color:white"></i>
                                    <div class="content">
                                    <h4 class="text-white mt-0 mb-1">Pending Count</h4>
                                        <lable class="text-white text-24 line-height-1 mb-1">0</lable>
                                        <p class="text-white text-14 mb-1">compared to last week</p>
                                    </div>
                                </div>
                            </div>
                        </div>
    </div>
    <div class="row">
                       
                       <div class="col-lg-4 col-md-6 col-sm-6">
                          
                             <div class="arrow arrow-right bg-danger text-white" style="width:300px;"> Invoice </div>    
                              
                       </div>  
                   </div>        
    <div class=row>
                        <div class="col-lg-2 col-md-2 col-sm-2">
                            <div class="card card-icon-bg card-icon-bg-white o-hidden mb-4 abc">
                                <div class="card-body bg-warning text-center">
                                    <div class="content">
                                    <i class="nav-icon fa-solid fa-calculator fa-1x " style="color:white"></i>
                                        <lable class="text-white text-24 line-height-1 mb-1 mt-2 "style="margin-left:15px;">20</lable>
                                        <p class="text-white text-16 mb-1">Today,s</p><br>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-2 col-md-2 col-sm-2">
                            <div class="card card-icon-bg card-icon-bg-white o-hidden mb-4 abc">
                                <div class="card-body bg-primary text-center">
                                    <div class="content">
                                    <i class="fa fa-eur fa-1x" aria-hidden="true" style="color:white"></i>
    
                                        <lable class="text-white text-24 line-height-1 mb-1 mt-2 "style="margin-left:15px;">20</lable>
                                        <p class="text-white text-16 mb-1">&nbsp;&nbsp;Total</p><br>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-2 col-md-2 col-sm-2">
                            <div class="card card-icon-bg card-icon-bg-white o-hidden mb-4 abc">
                                <div class="card-body bg-success text-center">
                                    <div class="content">
                                    <i class="nav-icon fa fa-hourglass-half fa-1x" aria-hidden="true" style="color:white"></i>
                                        <lable class="text-white text-24 line-height-1 mb-1 mt-2"style="margin-left:15px;">20</lable>
                                        <p class="text-white text-16 mb-1">Pending</p><br>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-2 col-md-2 col-sm-2">
                            <div class="card card-icon-bg card-icon-bg-white o-hidden mb-4 abc">
                                <div class="card-body bg-warning text-center">
                                    <div class="content">
                                    <i class="fa-sharp fa-solid fa-indian-rupee-sign fa-1x"aria-hidden="true"style=" margin-left:40px;color:white "></i>
                                        <lable class="text-white text-24 line-height-1 mb-1 mt-2 "style="margin-left:40px;">20</lable>
                                        <p class="text-white text-16 mb-1">Total Amount</p><br>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-2 col-md-2 col-sm-2">
                            <div class="card card-icon-bg card-icon-bg-white o-hidden mb-4 abc">
                                <div class="card-body bg-primary text-center">
                                    <div class="content">
                                    <i class="fa-sharp fa-solid fa-money-bill-1 fa-1x"aria-hidden="true"style="margin-left:40px; color:white "></i>
                                        <lable class="text-white text-24 line-height-1 mb-1 mt-2 "style="margin-left:50px;">20</lable>
                                        <p class="text-white text-16 mb-1" style="margin-left:6px;">Total Paid Amount</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-2 col-md-2 col-sm-2">
                            <div class="card card-icon-bg card-icon-bg-white o-hidden mb-4 abc">
                                <div class="card-body bg-success text-center">
                                    <div class="content">
                                    <i class="fa-sharp fa-solid fa-receipt fa-1x"aria-hidden="true"style=" margin-left:50px;color:white "></i>
                                        <lable class="text-white text-24 line-height-1 mb-1 mt-2"style="margin-left:50px;">20</lable>
                                        <p class="text-white text-16 mb-1" style="margin-left:10px;">Remaining Amount</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        
                        
    </div>
    
    
    <script  src="<?php echo base_url('web_resources');?>/dist/js/jquery.min.js"></script>          
    <script  src="<?php echo base_url('web_resources');?>/dist/js/controllers/StudentCreate.js"></script>
                       