<!-- =============== Left side End ================-->
<div class="main-content-wrap sidenav-open d-flex flex-column">
        <!-- ============ Body content start ============= -->
            <div class="main-content">
                <div class="breadcrumb">
                    <h1>Project Creation</h1>
                    <!-- <ul>
                        <li><a href="href.html">Form</a></li>
                        <li>Basic</li>
                    </ul> -->
                </div>
                <div class="separator-breadcrumb border-top"></div>
                <form role="form" id="Form" action="" method="post">
                    <div class="row">
                        <div class="col-12">
                            <div class="card ">
                                <div class="card-body">
                                    
                                    
                                    <br><div class="vh col-12"></div>
                                    <div class="row">
                                        <div class="col-4 form-group"><br>
                                            <label>Project Name<span class="text-danger">*</span></label><br>
                                            <input class="form-control" type="text" name="emp_name" id="Emp_name" >
                                        </div>
                                        <div class="col-4 form-group"><br>
                                            <label>Project Marathi Name<span class="text-danger">*</span></label><br>
                                            <input class="form-control" type="text" name="mobile" id="mobile" >
                                        </div>
                                        <div class="col-4 form-group"><br>
                                            <label>Project Short Name<span class="text-danger">*</span></label><br>
                                            <input class="form-control" type="text" name="mail" id="mail" >
                                        </div>

                                    </div>
                                    
                                    <div class="row">
                                    <div class="col-4 form-group mb-3">
                                                    <label for="country">Tags Name</label>
                                                    <select class="form-control" name="country" id="country">
                                                        <option value="1">--Tags --</option>
                                                        <option value="1">India</option>
                                                        <option value="2">Amerika</option>
                                                    </select>
                                                </div>
                                        

                                    </div>
                                
                                    <div class="row mt-2">
                                     <ul class="nav nav-pills ml-2" role="tablist">
                                        <li class="nav-item ">
                                            <a class="nav-link active" data-bs-toggle="pill" href="#details">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20 " fill="currentColor" class="bi bi-person-exclamation" viewBox="0 0 16 16">
                                                <path d="M11 5a3 3 0 1 1-6 0 3 3 0 0 1 6 0ZM8 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4Zm.256 7a4.474 4.474 0 0 1-.229-1.004H3c.001-.246.154-.986.832-1.664C4.484 10.68 5.711 10 8 10c.26 0 .507.009.74.025.226-.341.496-.65.804-.918C9.077 9.038 8.564 9 8 9c-5 0-6 3-6 4s1 1 1 1h5.256Z"/>
                                                <path d="M16 12.5a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0Zm-3.5-2a.5.5 0 0 0-.5.5v1.5a.5.5 0 0 0 1 0V11a.5.5 0 0 0-.5-.5Zm0 4a.5.5 0 1 0 0-1 .5.5 0 0 0 0 1Z"/>
                                                </svg>&nbsp; Details
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" data-bs-toggle="pill" href="#location">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="CurrentColor" class="bi bi-geo-alt-fill" viewBox="0 0 16 16">
                                                <path d="M8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10zm0-7a3 3 0 1 1 0-6 3 3 0 0 1 0 6z"/>
                                                </svg>&nbsp;Location
                                            </a>
                                        </li>
                                        <li class="nav-item nav-item-toggle">
                                            <a class="nav-link" data-bs-toggle="pill" href="#select">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-person-vcard-fill" viewBox="0 0 16 16">
                                                <path d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V4Zm9 1.5a.5.5 0 0 0 .5.5h4a.5.5 0 0 0 0-1h-4a.5.5 0 0 0-.5.5ZM9 8a.5.5 0 0 0 .5.5h4a.5.5 0 0 0 0-1h-4A.5.5 0 0 0 9 8Zm1 2.5a.5.5 0 0 0 .5.5h3a.5.5 0 0 0 0-1h-3a.5.5 0 0 0-.5.5Zm-1 2C9 10.567 7.21 9 5 9c-2.086 0-3.8 1.398-3.984 3.181A1 1 0 0 0 2 13h6.96c.026-.163.04-.33.04-.5ZM7 6a2 2 0 1 0-4 0 2 2 0 0 0 4 0Z"/>
                                                </svg>&nbsp;Overvview
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                                    <!-- Tab panes -->
                                    <div class="tab-content">
                                        <div id="details" class="container p-0 tab-pane active">
                                             
                                    <br><div class="vh col-12"></div>
                                    <div class="row ml-1">
                                        <!--<div class="col-lg-2 col-md-2 col-sm-2 col-xl-2 h6 form-group "><br>
                                            <input type="file"  accept="image/gif, image/jpeg, image/png" name="image" id="file" style="display: none;" onchange="loadFile(event)">
                                            <img id="output" width="100" style="border:2px solid; width:100px; height: 120px;" /><br>
                                            <br><label  class="h5 text-primary" for="file" style="cursor: pointer;">Upload Photo</label><br>
                                        </div>-->
                                        <div class=" col-4 form-group mb-3">
                                            <label for="date"> Start Date</label>
                                            <input class="form-control" id="date" type="date" name="date" value="<?php echo date('Y-m-d'); ?>" />
                                        </div>
                                        <div class=" col-4 form-group mb-3">
                                            <label for="date">End  Date</label>
                                            <input class="form-control" id="date" type="date" name="date" value="<?php echo date('Y-m-d'); ?>" />
                                        </div>
                                       
                                        
                                        <div class="col-2 form-group mt-4">
                                            <label for="name">Standard Flexible Flag:
                                                <input type="checkbox" name="flag" id="flag" checked>

                                            </label>
                                        </div>
                                        
                                    </div>
                                    <div class="row">
                                    
                                        
                                    </div>
                                        </div>
                                        <div id="location" class="container tab-pane fade ">
                                            
                                            <br><div class="vh col-12"></div>
                                            
                                            <div class="row">
                                                 <div class="col-lg-2 col-md-4 col-sm-12 col-xl-2 h6 form-group mb-3">
                                                    <label for="country">Project Type Name</label>
                                                    <select class="form-control" name="country" id="country">
                                                        <option value="1">--Project Type Name--</option>
                                                        <option value="1">India</option>
                                                        <option value="2">Amerika</option>
                                                    </select>
                                                </div>
                                                <div class="col-lg-2 col-md-4 col-sm-12 col-xl-2 h6 form-group mb-3">
                                                    <label for="state">Client Name</label>
                                                    <select class="form-control" name="state" id="state">
                                                        <option value="1">--Client Name--</option>
                                                        <option value="1">Maharastra</option>
                                                        <option value="2">Karnataka</option>
                                                    </select>
                                                </div>
                                                 <div class="col-lg-2 col-md-4 col-sm-12 col-xl-2 h6 form-group mb-3">
                                                    <label for="district">Task layout Name</label>
                                                    <select class="form-control" name="district" id="district">
                                                        <option value="1">--Task layout Name--</option>
                                                        <option value="1">Kolhapur</option>
                                                        <option value="2">Pune</option>
                                                    </select>
                                                </div>
                                                 <div class="col-lg-2 col-md-4 col-sm-12 col-xl-2 h6 form-group mb-3">
                                                    <label for="taluka">Group Type Name</label>
                                                    <select class="form-control" name="taluka" id="taluka">
                                                        <option value="1">--Group Type Name--</option>
                                                        <option value="1">Radhanagari</option>
                                                        <option value="2">Kagal</option>
                                                    </select>
                                                </div> 
                                            </div>
                                            <div class="row">
                                            <div class="col-lg-2 col-md-4 col-sm-12 col-xl-2 h6 form-group mb-3">
                                                   <label for="village">Project Access Type</label>
                                                   <select class="form-control" name="village" id="village" >
                                                       <option value="1">--Project Access Type--</option>
                                                       <option value="1">Walva Bk</option>
                                                       <option value="2">Bidri</option>
                                                   </select>
                                                </div>
                                                <div class="col-lg-2 col-md-4 col-sm-12 col-xl-2 h6 form-group mb-3">
                                                   <label for="village">Budget Type</label>
                                                   <select class="form-control" name="village" id="village" >
                                                       <option value="1">--Budget Type--</option>
                                                       <option value="1">Walva Bk</option>
                                                       <option value="2">Bidri</option>
                                                   </select>
                                                </div>
                                                <div class="col-lg-2 col-md-4 col-sm-12 col-xl-2 h6 form-group mb-3">
                                                   <label for="village">Currency Type</label>
                                                   <select class="form-control" name="village" id="village" >
                                                       <option value="1">--Currency--</option>
                                                       <option value="1">Walva Bk</option>
                                                       <option value="2">Bidri</option>
                                                   </select>
                                                </div>
                                            </div>
                                           
    
                           
                                            </div>
                                             

                                            </div>
                                        </div>
                                        <div id="select" class="container tab-pane fade">
                                             
                                            <br><div class="vh col-12"></div><br>
                                            <div class="row">
                                            <div class="row">
                                            <div class="toolbar">
			<div class="head">
				<input type="text" placeholder="Filename" value="untitled" id="filename">
				<select onchange="fileHandle(this.value); this.selectedIndex=0">
					<option value="" selected="" hidden="" disabled="">File</option>
					<option value="new">New file</option>
					<option value="txt">Save as txt</option>
					<option value="pdf">Save as pdf</option>
				</select>
				<select onchange="formatDoc('formatBlock', this.value); this.selectedIndex=0;">
					<option value="" selected="" hidden="" disabled="">Format</option>
					<option value="h1">Heading 1</option>
					<option value="h2">Heading 2</option>
					<option value="h3">Heading 3</option>
					<option value="h4">Heading 4</option>
					<option value="h5">Heading 5</option>
					<option value="h6">Heading 6</option>
					<option value="p">Paragraph</option>
				</select>
				<select onchange="formatDoc('fontSize', this.value); this.selectedIndex=0;">
					<option value="" selected="" hidden="" disabled="">Font size</option>
					<option value="1">Extra small</option>
					<option value="2">Small</option>
					<option value="3">Regular</option>
					<option value="4">Medium</option>
					<option value="5">Large</option>
					<option value="6">Extra Large</option>
					<option value="7">Big</option>
				</select>
				<div class="color">
					<span>Color</span>
					<input type="color" oninput="formatDoc('foreColor', this.value); this.value='#000000';">
				</div>
				<div class="color">
					<span>Background</span>
					<input type="color" oninput="formatDoc('hiliteColor', this.value); this.value='#000000';">
				</div>
			</div>
			<div class="btn-toolbar">
				<button onclick="formatDoc('undo')"><i class="fa-solid fa-rotate-left"></i></button>
				<button onclick="formatDoc('redo')"><i class="fa-sharp fa-solid fa-rotate-right"></i></button>
				<button onclick="formatDoc('bold')"><i class="fa-sharp fa-solid fa-bold"></i></button>
				<button onclick="formatDoc('underline')"><i class="fa-solid fa-underline"></i></button>
				<button onclick="formatDoc('italic')"><i class="fa-solid fa-italic"></i></button>
				<button onclick="formatDoc('strikeThrough')"><i class="fa-solid fa-strikethrough"></i></i></button>
				<button onclick="formatDoc('justifyLeft')"><i class="fa-sharp fa-solid fa-align-left"></i></button>
				<button onclick="formatDoc('justifyCenter')"><i class="fa-sharp fa-solid fa-align-center"></i></button>
				<button onclick="formatDoc('justifyRight')"><i class="fa-sharp fa-solid fa-align-right"></i></button>
				<button onclick="formatDoc('justifyFull')"><i class="fa-sharp fa-solid fa-align-justify"></i></button>
				<button onclick="formatDoc('insertOrderedList')"><i class="fa-solid fa-list-ol"></i></button>
				<button onclick="formatDoc('insertUnorderedList')"><i class="fa-solid fa-list-ul"></i></button>
				<button onclick="addLink()"><i class="fa-sharp fa-solid fa-link"></i></button>
				<button onclick="formatDoc('unlink')"><i class="fa-sharp fa-solid fa-unlink"></i></button>
				<button id="show-code" data-active="false">&lt;/&gt;</button>
			</div>
		</div>
		<div id="content" contenteditable="true" spellcheck="false">
			<textarea class="form-control" name="" id="" cols="102" rows="10"></textarea>
		</div>
	
    <style>
       ;

* {
	margin: 0;
	padding: 0;
	box-sizing: border-box;
	font-family: 'Poppins', sans-serif;
}

body {
	background: #ddd;
	display: flex;
	justify-content: center;
	align-items: center;
	min-height: 100vh;
}

li {
	margin-left: 16px;
}

a {
	cursor: pointer;
}




.container {
	max-width: 991px;
	width: 100%;
	background: #fff;
	border-radius: 8px;
	overflow: hidden;
}
.toolbar {
	padding: 16px;
	background: #eee;
}
.toolbar .head {
	display: flex;
	grid-gap: 10px;
	margin-bottom: 16px;
	flex-wrap: wrap;
}
.toolbar .head > input {
	max-width: 100px;
	padding: 6px 10px;
	border-radius: 6px;
	border: 2px solid #ddd;
	outline: none;
}
.toolbar .head select {
	background: #fff;
	border: 2px solid #ddd;
	border-radius: 6px;
	outline: none;
	cursor: pointer;
}
.toolbar .head .color {
	background: #fff;
	border: 2px solid #ddd;
	border-radius: 6px;
	outline: none;
	cursor: pointer;
	display: flex;
	align-items: center;
	grid-gap: 6px;
	padding: 0 10px;
}
.toolbar .head .color span {
	font-size: 14px;
}
.toolbar .head .color input {
	border: none;
	padding: 0;
	width: 26px;
	height: 26px;
	background: #fff;
	cursor: pointer;
}
.toolbar .head .color input::-moz-color-swatch {
	width: 20px;
	height: 20px;
	border: none;
	border-radius: 50%;
}
.toolbar .btn-toolbar {
	display: flex;
	flex-wrap: wrap;
	align-items: center;
	grid-gap: 10px;
}
.toolbar .btn-toolbar button {
	background: #fff;
	border: 2px solid #ddd;
	border-radius: 6px;
	cursor: pointer;
	width: 40px;
	height: 40px;
	display: flex;
	align-items: center;
	justify-content: center;
	font-size: 18px;
}
.toolbar .btn-toolbar button:hover {
	background: #f3f3f3;
}
#content {
	padding: 16px;
	outline: none;
	max-height: 50vh;
	overflow: auto;
}
#show-code[data-active="true"] {
	background: #eee;
}
    </style>
                                            </div>
                                            
                                            
                                            <br>
                                            
                                        </div>
                                        
                                     </div>
                                     <div class="col-md-12 text-right ">
                                     <button class="btn btn-info " type="button" name="cancle" id="cancle">Submit</button>
                                     <a href="<?=base_url() ?>Project/index"> <button class="btn btn-warning " type="button" name="cancle" id="cancle">Edit</button></a>
                                      </div>

                                </div>
                                
                            </div>
                              
                        </div>

                    </form>
                </div>

   


                  
<script>
var loadFile = function(event) {
    var image = document.getElementById('output');
    image.src = URL.createObjectURL(event.target.files[0]);
};
</script>
<script  src="<?php echo base_url('web_resources');?>/dist/js/jquery.min.js"></script>          
<script  src="<?php echo base_url('web_resources');?>/dist/js/controllers/StudentCreate.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
                   
                       
               
            