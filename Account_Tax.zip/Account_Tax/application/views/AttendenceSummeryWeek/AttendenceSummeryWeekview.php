
        <!-- =============== Left side End ================-->
        <div class="main-content-wrap sidenav-open d-flex flex-column">
            <!-- ============ Body content start ============= -->
            <div class="main-content">
                
                <!-- <div class="separator-breadcrumb border-top"></div> -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="card mb-4">
                            <div class="card-body">
                            <div class="breadcrumb">
                    <h1>Weekly Report</h1>
                </div>
                                <form role="form" id="Form" action="" method="post">
                                    <div class="row">
                                       
                                    <div class="col-md-2 form-group mb-3 ml-2">
                                        <label for="attendence">From Date:</label>
                                        <input type="date" class="form-control" id="attendence" placeholder="Enter AttendenceDate..." name="attendence" value="<?php echo date('Y-m-d'); ?>">                                    
                                    </div>

                                     

                                    <div class="col-md-1 mt-4 mb-3 text-right">
                                       <button class="btn btn-success" type="button" name="btn_search" id="btn_search"><i class="nav-icon fa-regular fa-circle-check"></i> Search</button>
                                    </div> &emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&nbsp;

                                    
                                    </div> 
                                    <!-- <div class="col-md-12 text-right">
                                    <input type="text"name="search" placeholder="Search Here.."> -->
                                    <!-- <i class="fa fa-search"></i> -->
                                    <!-- </div> -->

                                   
                                    <div class="table-responsive">
                                    <table class="display table table-striped table-bordered text-center" id="example" style="width:100%"> 
                                        
                                            <tr class="border">
                                                <td class="border" rowspan="2">Name</td>
                                                <td class="border">Thu</td>
                                                <td class="border">Fri</td>         
                                                <td class="border">Sat</td>
                                                <td class="border">Sun</td>
                                                <td class="border">Mon</td>
                                                <td class="border">Tue</td>
                                                <td class="border">Wed</td>
                                                <td class="border" rowspan="2">Per Day</td>
                                                <td class="border" rowspan="2">Present</td>
                                                <td class="border" rowspan="2">Absent</td>
                                                <td class="border" rowspan="2">Half-Day</td>
                                                <td class="border" rowspan="2">Over-Time</td>
                                                <td class="border" rowspan="2">Total Days</td>
                                                <td class="border" rowspan="2">Total Amount</td>
                                                <td class="border" rowspan="2">Sign</td>

                                            </tr>
                                      
                                        

                                        <tr class="border">
                                                <td>2022-12-01</td>
                                                <td>2022-12-02</td>
                                                <td>2022-12-03</td>
                                                <td>2022-12-04</td>
                                                <td>2022-12-05</td>
                                                <td>2022-12-06</td>
                                                <td>2022-12-07</td>
                                            </tr> </b>

                                            <tr>
                                                <td>Rutuja</td>
                                                <td>Present</td>
                                                <td>-</td>
                                                <td>-</td>
                                                <td>-</td>
                                                <td>-</td>
                                                <td>-</td>
                                                <td>-</td>
                                                <td>100</td>
                                                <td>1</td>
                                                <td>0</td>
                                                <td>0</td>
                                                <td>1</td>
                                                <td>1</td>
                                                <td>100</td>
                                                <td></td>
                                                
                                            </tr> 
                           
                                           
                                            <tr>
                                                <td colspan="14">Total Amount</td>
                                                <td colspan="2">100</td>
                                               

                                            </tr>
                                    </table>
                                </div>
     
                                <div class="col-md-12 text-right">
                                     <a href="<?=base_url() ?>"> <button class="btn btn-outline-info" type="button" name="submit" id="submit"><i class="fa-solid fa-check"></i>&nbsp;submit</button></a>

                                     <a href="<?=base_url() ?>"> <button class="btn btn-outline-warning " type="button" name="edit" id="edit"><i class="fa-solid fa-user-pen"></i>&nbsp;Edit</button></a>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
</div>
                  

<script  src="<?php echo base_url('web_resources');?>/dist/js/jquery.min.js"></script>          
<script  src="<?php echo base_url('web_resources');?>/dist/js/controllers/Familytypecreate.js"></script>
                   
                       
               
            