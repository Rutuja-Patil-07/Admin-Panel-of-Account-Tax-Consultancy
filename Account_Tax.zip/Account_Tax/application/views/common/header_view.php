<!DOCTYPE html>
<html lang="en" dir="">


<!-- Mirrored from demos.ui-lib.com/gull/html/layout1/upload.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 11 Oct 2022 05:16:54 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title> Account & Tax </title>
    <link href="https://fonts.googleapis.com/css?family=Nunito:300,400,400i,600,700,800,900" rel="stylesheet" />

    <link href="<?=base_url();?>Assets/css/style.css" rel="stylesheet" />

    <link href="<?=base_url();?>Assets/css/plugins/perfect-scrollbar.min.css" rel="stylesheet" />

    <link rel="stylesheet" href="<?=base_url();?>Assets/css/plugins/dropzone.min.css" />
    <link rel="stylesheet" href="<?=base_url();?>Assets/css/plugins/datatables.min.css" />


    
    <link rel="icon" href="<?=base_url() ?>Assets/images/studentlogo.png" sizes="32x32" type="image/png">
   
    <!-- ******* Added New Links***** -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>web_resources/dist/css/sweetalert.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.1/css/all.min.css"  />
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.1/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css"/>
    
    <script>
        var base_path="<?php echo base_url();?>";
     </script>


</head>

<body class="text-left">
    <div class="app-admin-wrap layout-sidebar-large">
        <div class="main-header">
            <!-- <div class="logo">
                <img src="<?=base_url();?>Assets/images/logo.png" alt="">
            </div> -->
            <div class="menu-toggle ml-5">
                <div></div>
                <div></div>
                <div></div>
            </div>
            <div class="d-flex align-items-center">
                <!-- Mega menu -->
                <div class="dropdown mega-menu d-none d-md-block">
                    <!-- <a href="#" class="btn text-muted dropdown-toggle mr-3" id="dropdownMegaMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Mega Menu</a> -->
                    <div class="dropdown-menu text-left" aria-labelledby="dropdownMenuButton">
                        <div class="row m-0">
                            <div class="col-md-4 p-4 bg-img">
                                <h2 class="title">Mega Menu <br> Sidebar</h2>
                                <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Asperiores natus laboriosam fugit, consequatur.
                                </p>
                                <p class="mb-4">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Exercitationem odio amet eos dolore suscipit placeat.</p>
                                <button class="btn btn-lg btn-rounded btn-outline-warning">Learn More</button>
                            </div>
                            <div class="col-md-4 p-4">
                                <p class="text-primary text--cap border-bottom-primary d-inline-block">Features</p>
                                <div class="menu-icon-grid w-auto p-0">
                                    <a href="#"><i class="i-Shop-4"></i> Home</a>
                                    <a href="#"><i class="i-Library"></i> UI Kits</a>
                                    <a href="#"><i class="i-Drop"></i> Apps</a>
                                    <a href="#"><i class="i-File-Clipboard-File--Text"></i> Forms</a>
                                    <a href="#"><i class="i-Checked-User"></i> Sessions</a>
                                    <a href="#"><i class="i-Ambulance"></i> Support</a>
                                </div>
                            </div>
                            <div class="col-md-4 p-4">
                                <p class="text-primary text--cap border-bottom-primary d-inline-block">Components</p>
                                <ul class="links">
                                    <li><a href="<?=base_url();?>accordion.html">Accordion</a></li>
                                    <li><a href="<?=base_url();?>alerts.html">Alerts</a></li>
                                    <li><a href="<?=base_url();?>buttons.html">Buttons</a></li>
                                    <li><a href="<?=base_url();?>badges.html">Badges</a></li>
                                    <li><a href="<?=base_url();?>carousel.html">Carousels</a></li>
                                    <li><a href="<?=base_url();?>lists.html">Lists</a></li>
                                    <li><a href="<?=base_url();?>popover.html">Popover</a></li>
                                    <li><a href="<?=base_url();?>tables.html">Tables</a></li>
                                    <li><a href="<?=base_url();?>datatables.html">Datatables</a></li>
                                    <li><a href="<?=base_url();?>modals.html">Modals</a></li>
                                    <li><a href="<?=base_url();?>nouislider.html">Sliders</a></li>
                                    <li><a href="<?=base_url();?>tabs.html">Tabs</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- / Mega menu -->
                <!-- <div class="search-bar">
                    <input type="text" placeholder="Search">
                    <i class="search-icon text-muted i-Magnifi-Glass1"></i>
                </div> -->
            </div>
            <div style="margin: auto"></div>
            <div class="header-part-right">
                <!-- Full screen toggle -->
             
                <!-- Notificaiton -->
                <div class="dropdown">
                    <!-- <div class="badge-top-container" role="button" id="dropdownNotification" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <span class="badge badge-primary">3</span>
                        <i class="i-Bell text-muted header-icon"></i>
                    </div> -->
                    <!-- Notification dropdown -->
                    <div class="dropdown-menu dropdown-menu-right notification-dropdown rtl-ps-none" aria-labelledby="dropdownNotification" data-perfect-scrollbar data-suppress-scroll-x="true">
                      
                    
                        <div class="dropdown-item d-flex">
                            <div class="notification-icon">
                                <i class="i-Data-Power text-success mr-1"></i>
                            </div>
                            <div class="notification-details flex-grow-1">
                                <p class="m-0 d-flex align-items-center">
                                    <span>Server Up!</span>
                                    <span class="badge badge-pill badge-success ml-1 mr-1">3</span>
                                    <span class="flex-grow-1"></span>
                                    <span class="text-small text-muted ml-auto">14 hours ago</span>
                                </p>
                                <p class="text-small text-muted m-0">Server rebooted successfully</p>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Notificaiton End -->
                <!-- User avatar dropdown -->
                <div class="dropdown">
                    <div class="user col align-self-end">
                        <img src="<?=base_url();?>Assets\images\tax1.jpg" id="userDropdown" alt="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
                            <!-- <div class="dropdown-header">
                                <i class="i-Lock-User mr-1"></i> Timothy Carlson
                            </div> -->
                            <!-- <a class="dropdown-item">Account settings</a>
                            <a class="dropdown-item">Billing history</a> -->
                            <a class="dropdown-item" href="signin.html">Log out</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="side-content-wrap">
            <div class="sidebar-left open rtl-ps-none" data-perfect-scrollbar="" data-suppress-scroll-x="true">
                <ul class="navigation-left">
                    <li class="nav-item" ><a class="nav-item-hold" href="<?=base_url();?>Dashboard"><img src="<?=base_url() ?>Assets/images/img6.png" alt="img" style="width:20px;"><span class="nav-text">Dashboard</span></a>
                        
                    </li>
 <li class="nav-item" data-item="uikit"><a class="nav-item-hold" href="<?=base_url();?>User Management"><img src="<?=base_url() ?>Assets\images\img14.png" alt="img" style="width:35px;"><span class="nav-text">User Management</span></a>
                        
                        </li>
                    <li class="nav-item" data-item="uikits"><a class="nav-item-hold" href="<?=base_url();?>Employee"><img src="<?=base_url() ?>Assets/images/img4.jpeg" alt="img" style="width:35px;"><span class="nav-text">Employee</span></a>
                        
                    </li>
                    <li class="nav-item" data-item="extrakits"><a class="nav-item-hold" href="<?=base_url();?>Attendance"><img src="<?=base_url() ?>Assets/images/img5.png" alt="img" style="width:20px;"><span class="nav-text">Attendence</span></a>
                       
                    </li>
                    <li class="nav-item" data-item="apps"><a class="nav-item-hold" href="<?=base_url();?>Work Allocation"><img src="<?=base_url() ?>Assets\images\img7.jpeg" alt="img" style="width:30px;"><span class="nav-text">Work Allocation</span></a>
                        
                    </li>
                    <li class="nav-item" data-item="widgets"><a class="nav-item-hold" href="<?=base_url();?>Document Master"><img src="<?=base_url() ?>Assets\images\img8.jpg" alt="img" style="width:50px;"><span class="nav-text">Document Master</span></a>
                       
                    </li>
                    <li class="nav-item" data-item="forms"><a class="nav-item-hold" href="<?=base_url();?>Master"><img src="<?=base_url() ?>Assets\images\img9.webp" alt="img" style="width:25px;"><span class="nav-text">Master</span></a>
                       
                    </li>
                    <li class="nav-item" data-item="charts"><a class="nav-item-hold" href="<?=base_url();?>Call & Postal"><img src="<?=base_url() ?>Assets\images\img10.png" alt="img" style="width:25px;"><span class="nav-text">Call & Postal</span></a>
                       
                    </li>
                    <li class="nav-item"><a class="nav-item-hold" href="<?=base_url();?>Bill/create"><img src="<?=base_url() ?>Assets\images\img9.webp" alt="img" style="width:30px;"><span class="nav-text">Receipt & Bill</span></a>
                       
                       </li>
                    
                   
                    <li class="nav-item"><a class="nav-item-hold" href="<?=base_url();?>Report"><img src="<?=base_url() ?>Assets\images\img11.png" alt="img" style="width:20px;"><span class="nav-text">Report</span></a>
                       
                </li>
                    <li class="nav-item"><a class="nav-item-hold" href="<?=base_url();?>Logout"><img src="<?=base_url() ?>Assets\images\img13.png" alt="img" style="width:20px;"><span class="nav-text">Logout</span></a>
                        
                    </li>
                    
                   
                </ul>
            </div>
            <div class="sidebar-left-secondary rtl-ps-none" data-perfect-scrollbar="" data-suppress-scroll-x="true">
                <!-- Submenu Dashboards-->
                <!-- <ul class="childNav" data-parent="dashboard">
                    <li class="nav-item"><a href="<?=base_url();?>dashboard1.html"><i class=" nav-icon nav-icon i-Clock-3"></i><span class="item-name">Student create</span></a></li>
                    <li class="nav-item"><a href="<?=base_url();?>dashboard2.html"><i class=" nav-icon nav-icon i-Clock-4"></i><span class="item-name">Student Edit</span></a></li>
                    <li class="nav-item"><a href="<?=base_url();?>dashboard3.html"><i class=" nav-icon nav-icon i-Over-Time"></i><span class="item-name">Verify Student</span></a></li>
                    <li class="nav-item"><a href="<?=base_url();?>dashboard4.html"><i class=" nav-icon nav-icon i-Clock"></i><span class="item-name">Unverify student</span></a></li>
                </ul> -->
                <!-- chartjs-->
                <ul class="childNav" data-parent="charts">
                    <li class="nav-item"><a href="<?=base_url();?>CallLog/create"><img src="https://img.icons8.com/color/2x/call-list.png" style="width:25px;"><span class="item-name">&nbsp;<u>Call Log</u></span></a></li>
                    <li class="nav-item"><a href="<?=base_url();?>Postalrecive/create"><img src="https://img.icons8.com/dusk/2x/send-box.png" style="width:25px;"><span class="item-name">&nbsp;<u>Postal Recive</u></span></a></li>
                    <li class="nav-item"><a href="<?=base_url();?>Postaldispatch/create"><img src="https://img.icons8.com/dusk/2x/checked-truck.png" style="width:25px;"><span class="item-name">&nbsp;<u>Postal Dispatch</u></span></a></li>
                    <li class="nav-item"><a href="<?=base_url();?>Enquiry/create"><img src="https://img.icons8.com/arcade/2x/why-us-male.png" style="width:25px;"><span class="item-name">&nbsp;<u>Enquiry</u></span></a></li>
                    <li class="nav-item"><a href="<?=base_url();?>Staffmessage/create"><img src="https://img.icons8.com/fluency/512/multiple-messages.png" style="width:25px;"><span class="item-name">&nbsp;<u>Staff Message</u></span></a></li>
                    <li class="nav-item"><a href="<?=base_url();?>Report"><img src="https://img.icons8.com/color-glass/2x/test-results.png" style="width:25px;"><span class="item-name">&nbsp;<u>Report</u></span></a></li>
                </ul>

                
                <ul class="childNav" data-parent="apps">
                    <li class="nav-item"><a href="<?=base_url();?>Project/create"><img src="https://img.icons8.com/nolan/2x/project.png" style="width:25px;"><span class="item-name">&nbsp;<u>Project Creation</u></span></a></li>
                    <li class="nav-item"><a href="<?=base_url();?>Project"><img src="https://img.icons8.com/arcade/2x/edit-property.png" style="width:25px;"><span class="item-name">&nbsp;<u>Modify Project</u></span></a></li>
                    <li class="nav-item"><a href="<?=base_url();?>Taskview/create"><img src="https://img.icons8.com/fluency/512/what-i-do.png" style="width:25px;"><span class="item-name">&nbsp;<u>Task Creation</u></span></a></li>             
                   <li class="nav-item"><a href="<?=base_url();?>Work/create"><img src="https://img.icons8.com/bubbles/2x/under-computer.png" style="width:25px;"><span class="item-name">&nbsp;<u>Work Assign</u></span></a></li>
                    <li class="nav-item"><a href="<?=base_url();?>Work"><img src="https://img.icons8.com/cute-clipart/2x/edit-property.png" style="width:25px;"><span class="item-name">&nbsp;<u>Modify Work</u></span></a></li>
                    <li class="nav-item"><a href="<?=base_url();?>Daily/create"><img src="https://img.icons8.com/stickers/2x/journal.png" style="width:25px;"><span class="item-name">&nbsp;<u>Daily Diary</u></span></a></li>
                    <li class="nav-item"><a href="<?=base_url();?>Worka/create"><img src="https://img.icons8.com/avantgarde/2x/overview-pages-2.png" style="width:25px;"><span class="item-name">&nbsp;<u>Work Allocation</u></span></a></li>
                    <li class="nav-item"><a href="<?=base_url();?>Company"><img src="https://img.icons8.com/stickers/2x/test-results.png" style="width:25px;"><span class="item-name">&nbsp;<u>Report</u></span></a></li>

                </ul>
                <ul class="childNav" data-parent="widgets">
                    <li class="nav-item"><a href="<?=base_url();?>Document/create"><img src="https://img.icons8.com/arcade/2x/documents.png" style="width:25px;"><span class="item-name">&nbsp;<u>Document Customer</u></span></a></li>
                    <li class="nav-item"><a href="<?=base_url();?>Document/createfile"><img src="https://img.icons8.com/stickers/2x/upload-document.png" style="width:25px;"><span class="item-name">&nbsp;<u>Upload General Document</u></span></a></li>
                    <li class="nav-item"><a href="<?=base_url();?>widget-list.html"><img src="https://img.icons8.com/cute-clipart/2x/edit-file.png" style="width:25px;"><span class="item-name">&nbsp;<u>Modify Document</u></span></a></li>
                    <li class="nav-item"><a href="<?=base_url();?>Document/handover"><img src="https://img.icons8.com/color/512/signing-a-document.png" style="width:25px;"><span class="item-name">&nbsp;<u>Document Handover</u></span></a></li>
                    <li class="nav-item"><a href="<?=base_url();?>widget-list.html"><img src="https://img.icons8.com/fluency/512/signing-a-document.png" style="width:25px;"><span class="item-name">&nbsp;<u>Modify Handover Document</u></span></a></li>
                    <li class="nav-item"><a href="<?=base_url();?>widget-list.html"><img src="https://img.icons8.com/color/512/google-forms-new-logo-1.png" style="width:25px;"><span class="item-name">&nbsp;<u>Report</u></span></a></li>

                  
                </ul>
                

                <ul class="childNav" data-parent="forms">
                    <li class="nav-item"><a href="<?=base_url();?>Role"><i class=" nav-icon nav-icon i-Split-Vertical"></i><span class="item-name">Role</span></a></li>

                    <li class="nav-item"><a href="<?=base_url();?>Designation"><i class=" nav-icon nav-icon i-Split-Vertical"></i><span class="item-name">Designation</span></a></li>

                    <li class="nav-item"><a href="<?=base_url();?>Deparment"><i class=" nav-icon nav-icon i-Receipt-4"></i><span class="item-name">Deparment</span></a></li>

                    <li class="nav-item"><a href="<?=base_url();?>Education"><i class=" nav-icon nav-icon i-Close-Window"></i><span class="item-name">Education</span></a></li>

                    <li class="nav-item"><a href="<?=base_url();?>Country/create"><img src="https://img.icons8.com/fluency/2x/country.png" style="width:25px;"><span class="item-name">&nbsp;<u>Country</u></span></a></li>

                    <li class="nav-item"><a href="<?=base_url();?>State/create"><img src="https://img.icons8.com/bubbles/2x/city.png" style="width:25px;"><span class="item-name">&nbsp;<u>State</u></span></a></li>
                    
                    <li class="nav-item"><a href="<?=base_url();?>District/create"><img src="https://img.icons8.com/bubbles/512/city-buildings.png" style="width:25px;"><span class="item-name">&nbsp;<u>District</u></span></a></li>

                    <li class="nav-item"><a href="<?=base_url();?>Taluka/create"><img src="https://img.icons8.com/dusk/2x/building.png" style="width:25px;"><span class="item-name">&nbsp;<u>Taluka</u></span></a></li>

                    <li class="nav-item"><a href="<?=base_url();?>Village/create"><img src="https://img.icons8.com/dusk/2x/real-estate.png" style="width:25px;"><span class="item-name">&nbsp;<u>Village</u></span></a></li>

                    <li class="nav-item"><a href="<?=base_url();?>City/create"><img src="https://img.icons8.com/bubbles/512/city.png" style="width:25px;"><span class="item-name">&nbsp;<u>City</u></span></a></li>

                    <li class="nav-item"><a href="<?=base_url();?>Branch/create"><img src="https://img.icons8.com/color-glass/2x/israeli-parliament.png" style="width:25px;"><span class="item-name">&nbsp;<u>Branch</u></span></a></li>

                    <li class="nav-item"><a href="<?=base_url();?>Customer/create"><img src="https://img.icons8.com/bubbles/512/gender-neutral-user.png" style="width:25px;"><span class="item-name">&nbsp;<u>Customer</u></span></a></li>
                    <li class="nav-item"><a href="<?=base_url();?>Category/create"><img src="https://img.icons8.com/color/512/categorize.png" style="width:25px;"><span class="item-name">&nbsp;<u>Category</u></span></a></li>

                    <li class="nav-item"><a href="<?=base_url();?>Task/create"><img src="https://img.icons8.com/cute-clipart/2x/task.png" style="width:25px;"><span class="item-name">&nbsp;<u>Task</u></span></a></li>
                    <li class="nav-item"><a href="<?=base_url();?>TaskType/create"><img src="https://img.icons8.com/nolan/2x/task.png" style="width:25px;"><span class="item-name">&nbsp;<u>TaskType</u></span></a></li>

                </ul>



                <ul class="childNav" data-parent="extrakits">
                    <li class="nav-item"><a href="<?=base_url();?>CreateAttendence/create"><img src="https://img.icons8.com/dusk/2x/user-male-circle--v1.png" style="width:25px;"><span class="item-name">&nbsp;<u>Create Attendence</u></span></a></li>
                    <li class="nav-item"><a href="<?=base_url();?>AttendenceDetails"><img src="https://img.icons8.com/stickers/2x/attendance-mark.png" style="width:25px;"><span class="item-name">&nbsp;<u>Modify Attendence</u></span></a></li>
                    <li class="nav-item"><a href="<?=base_url();?>AttendenceReport"><img src="https://img.icons8.com/color/2x/google-forms-new-logo-1.png" style="width:25px;"><span class="item-name">&nbsp;<u>Attendence Report</u></span></a></li>
                    <li class="nav-item"><a href="<?=base_url();?>DailyAttendence"><img src="https://img.icons8.com/stickers/2x/groups.png" style="width:25px;"><span class="item-name">&nbsp;<u>Daily Attendence List</u></span></a></li>
                    <li class="nav-item"><a href="<?=base_url();?>AttendenceSummeryWeek"><img src="https://img.icons8.com/dusk/2x/sunday.png" style="width:25px;"><span class="item-name">&nbsp;<u>Weekly Report</u></span></a></li>
                    <li class="nav-item"><a href="<?=base_url();?>MonthlyReport"><img src="https://img.icons8.com/dusk/2x/calendar--v1.png" style="width:25px;"><span class="item-name">&nbsp;<u>Monthly Report</u></span></a></li>
                    <li class="nav-item"><a href="<?=base_url();?>AttendenceSummery"><img src="https://img.icons8.com/nolan/2x/summary-list.png" style="width:25px;"><span class="item-name">&nbsp;<u>Attendence Summary</u></span></a></li>


                </ul>
<ul class="childNav" data-parent="uikit">
                    <li class="nav-item"><a href="<?=base_url('User/create');?>"><img src="https://img.icons8.com/plasticine/256/create-new.png" style="width:25px;"><span class="item-name">&nbsp;<u>Create User</u></span></a></li>
                    <li class="nav-item"><a href="<?=base_url();?>#"><img src="https://img.icons8.com/plasticine/256/approve-and-update.png" style="width:25px;"><span class="item-name">&nbsp;<u>Update User</u></span></a></li>
                    <li class="nav-item"><a href="<?=base_url();?>#"><img src="https://img.icons8.com/dusk/256/remove-user-female.png" style="width:25px;"><span class="item-name">&nbsp;<u>Deactivate User</u></span></a></li>
                    <li class="nav-item"><a href="<?=base_url();?>#"><img src="https://img.icons8.com/dusk/256/list.png" style="width:25px;"><span class="item-name">&nbsp;<u>User List<u></span></a></li>
                     </ul>
                <ul class="childNav" data-parent="uikits">
                    <li class="nav-item"><a href="<?=base_url('Employee/create');?>"><img src="https://img.icons8.com/dusk/2x/add-file--v1.png" style="width:25px;"><span class="item-name">&nbsp;<u>New Employee</u></span></a></li>
                    <li class="nav-item"><a href="<?=base_url();?>Employee"><img src="https://img.icons8.com/dusk/2x/edit-property.png" style="width:25px;"><span class="item-name">&nbsp;<u>Modify Employee</u></span></a></li>
                    <li class="nav-item"><a href="<?=base_url();?>EmployeeDetailsviewdelete"><img src="https://img.icons8.com/dusk/2x/delete-file.png" style="width:25px;"><span class="item-name">&nbsp;<u>Deactive Employee</u></span></a></li>
                    <li class="nav-item"><a href="<?=base_url();?>Employee_List"><img src="https://img.icons8.com/color-glass/2x/shortlist.png" style="width:25px;"><span class="item-name">&nbsp;<u>Employee List<u></span></a></li>
                    <li class="nav-item"><a href="<?=base_url();?>Employee"><img src="https://img.icons8.com/stickers/2x/pass.png" style="width:25px;"><span class="item-name">&nbsp;<u>Report</u></span></a></li>
                </ul>
                <ul class="childNav" data-parent="sessions">
                    <li class="nav-item"><a href="http://demos.ui-lib.com/gull/html/sessions/signin.html"><i class=" nav-icon nav-icon i-Checked-User"></i><span class="item-name">Sign in</span></a></li>
                    <li class="nav-item"><a href="http://demos.ui-lib.com/gull/html/sessions/signup.html"><i class=" nav-icon nav-icon i-Add-User"></i><span class="item-name">Sign up</span></a></li>
                    <li class="nav-item"><a href="http://demos.ui-lib.com/gull/html/sessions/forgot.html"><i class=" nav-icon nav-icon i-Find-User"></i><span class="item-name">Forgot</span></a></li>
                </ul>
                <ul class="childNav" data-parent="others">
                    <li class="nav-item"><a href="http://demos.ui-lib.com/gull/html/sessions/not-found.html"><i class=" nav-icon nav-icon i-Error-404-Window"></i><span class="item-name">Not Found</span></a></li>
                    <li class="nav-item"><a href="<?=base_url();?>user.profile.html"><i class=" nav-icon nav-icon i-Male"></i><span class="item-name">User Profile</span></a></li>
                    <li class="nav-item"><a class="open" href="<?=base_url();?>blank.html"><i class=" nav-icon nav-icon i-File-Horizontal"></i><span class="item-name">Blank Page</span></a></li>
                </ul>
            </div>
            <div class="sidebar-overlay"></div>
        </div>