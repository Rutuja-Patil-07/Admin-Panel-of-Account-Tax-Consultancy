
        <!-- =============== Left side End ================-->
        <div class="main-content-wrap sidenav-open d-flex flex-column">
            <!-- ============ Body content start ============= -->
            <div class="main-content">
               
                <!-- <div class="separator-breadcrumb border-top"></div> -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="card mb-4">
                            <div class="card-body">
                            <div class="breadcrumb">
                    <h1>Create Attendence</h1>
                   
                </div>
                                <form role="form" id="Form" action="" method="post">
                                    <div class="row">
                                        <div class="col-md-2 form-group mb-3 ml-2">
                                        <label for="attendence">Attendence Date:</label>
                                        <input type="date" class="form-control" id="attendence" placeholder="Enter AttendenceDate..." name="attendence" value="<?php echo date('Y-m-d'); ?>">                                        </div>
                                       
                                       

                                       <div class="col-md-1 mt-4 mb-3 text-right">
                                       <button class="btn btn-success" type="button" name="btn_search" id="btn_search"><i class="nav-icon fa-regular fa-circle-check"></i> Search</button>
                                    </div>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;&nbsp;

                                    

                                   

                                    <div class="table-responsive">
                                    <table class="display table table-striped table-bordered" id="example" style="width:100%">
                                        <thead>
                                            <tr class="border">
                                                <th>Employee Id</th>
                                                <th>Employee Name</th>
                                                <th>Type</th>
                                                <th>Description</th>
                                                
                                            </tr>
                                            <tr >
                                                <th> <input type="number" class="form-control" id="id" name="id" >                                      
                                                </th>
                                                <th><input type="text" class="form-control" id="name" name="name" ></th>
                                                <th><select class="form-control" name="type" id="type">
                                                <option value="select">---Select---</option>
                                                <option value="Half">Half-Day</option>
                                                <option value="Present">Present</option>
                                                <option value="Absent">Absent</option>
                                               
                                            </select></th>
                                                <th><input type="text" class="form-control" id="description" name="description" > </th>
                                                
                                            </tr>
                                            
                                        </thead>
                                        <tbody>
                                        <tr>
                                                
                                                
                                            </tr>

                                                                       </tbody>
                                        
                                    </table>
                                </div>
                                <div class="col-md-12 text-right">
                                     <button class="btn btn-outline-info" type="button" name="btn_save" id="btn_save"><i class="fa-solid fa-check"></i>&nbsp;submit</button>

                                     <a href="<?=base_url() ?>CreateAttendence/index"> <button class="btn btn-outline-warning " type="button" name="edit" id="edit"><i class="fa-solid fa-user-pen"></i>&nbsp;Edit</button></a>
                                        </div>
                                          

                                        
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
</div>
                  

<script  src="<?php echo base_url('web_resources');?>/dist/js/jquery.min.js"></script>          
<script  src="<?php echo base_url('web_resources');?>/dist/js/controllers/attendence.js"></script>
                   
                       
               
            