
        <!-- =============== Left side End ================-->
        <div class="main-content-wrap sidenav-open d-flex flex-column">
            <!-- ============ Body content start ============= -->
            <div class="main-content">
               
                <!-- <div class="separator-breadcrumb border-top"></div> -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="card mb-4">
                            <div class="card-body">
                            <div class="breadcrumb">
                    <h1>Customer</h1>
                   
                </div>
                                <form role="form" id="Form" action="" method="post">
                                    <div class="row">
                                        <div class="col-md-2 form-group mb-3">
                                            <label for="firstName1"> first Name</label>
                                            <input class="form-control" id="firstname" type="text"  name="firstname" value="" />
                                        </div>
                                        <div class="col-md-2 form-group mb-3">
                                            <label for="middleName1"> Middle Name</label>
                                            <input class="form-control" id="middlename" type="text"  name="middlename" value="" />
                                        </div>
                                        <div class="col-md-2 form-group mb-3">
                                            <label for="lastName1"> Last Name</label>
                                            <input class="form-control" id="lastName" type="text"  name="lastName" value="" /><br>
                                        </div>
                                        <div class="col-md-1 form-group mb-3 sm-none">
                                            </div>
                                            <div class="col-md-3 form-group mb-3">
                                            <label for="state">State</label>
                                            <input class="form-control" id="state" type="text"  name="state" value="" />
                                        </div>
                                        <div class="col-md-6 form-group mb-3">
                                            <label for="group">Group</label>
                                            <input class="form-control" id="group" type="text"  name="group" value="" />
                                        </div>
                                        <div class="col-md-1 form-group mb-3 sm-none">
                                           
                                            </div>
                                            <div class="col-md-3 form-group mb-3">
                                            <label for="email">Email</label>
                                            <input class="form-control" id="email" type="text" name="email" value="" />
                                        </div>
                                        <div class="col-md-6 form-group mb-3">
                                            <label for="address">Address.</label>
                                            <textarea class="form-control" id="address" type="text"  name="address" value="" ></textarea>
                                        </div>
                                        <div class="col-md-1 form-group mb-3 sm-none">
                                            
                                            </div>
                                            <div class="col-md-3 form-group mb-3">
                                            <label for="phone">Mobile No.</label>
                                            <input class="form-control" id="phone" type="number" maxlength="10" name="phone" value="" />
                                        </div>
                                        <div class="col-md-3 form-group mb-3">
                                            <label for="city"> City</label>
                                            <input class="form-control" id="city" type="text"  name="city" value="" />
                                        </div>  
                                        <div class="col-md-3 form-group mb-3">
                                            <label for="pincode">Pincode.</label>
                                            <input class="form-control" id="pincode" type="number" maxlength="6"  name="pincode" value="" />
                                        </div>
                                        <div class="col-md-1 form-group mb-3 sm-none">
                                           
                                            </div>
                                        <div class="col-md-3 form-group mb-3">
                                            <label for="pan">PAN</label>
                                            <input class="form-control" id="pan" type="text"  name="pan" value="" />
                                        </div>
                                        <div class="col-md-6 form-group mb-3">
                                        </div>
                                        <div class="col-md-1 form-group mb-3 sm-none">
                                           
                                            </div>
                                            <div class="col-md-4 form-group mb-3">
                                            <label for="email">Allow Web Login</label>
                                        </div>
                                        <div class="col-md-6 form-group mb-3">
                                        </div>
                                        <div class="col-md-1 form-group mb-3 sm-none">
                                           
                                            </div>
                                            <div class="col-md-3 form-group mb-3">
                                            <label for="password">Password</label>
                                            <input class="form-control" id="password" type="password" name="password" value="" />
                                            <input type="checkbox" id="showPassword" name="checkbox" value="checkbox">
                                            <label for="showPassword">View Password</label><br>
                                       
                                        </div>
                                        
                                        <div class="col-md-12 text-right">
                                     <button class="btn btn-outline-info" type="button" name="btn_save" id="btn_save"><i class="fa-solid fa-check"></i>&nbsp;submit</button>

                                     <a href="<?=base_url() ?>Customer/index"> <button class="btn btn-outline-warning " type="button" name="edit" id="edit"><i class="fa-solid fa-user-pen"></i>&nbsp;Edit</button></a>
                                        </div>
                                      
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
</div>
                  

<script  src="<?php echo base_url('web_resources');?>/dist/js/jquery.min.js"></script>          
<script  src="<?php echo base_url('web_resources');?>/dist/js/controllers/customer.js"></script>
<script>
    document.getElementById('showPassword').onclick = function() {
    if ( this.checked ) {
       document.getElementById('password').type = "text";
    } else {
       document.getElementById('password').type = "password";
    }
};
</script>                   
                       
               
            