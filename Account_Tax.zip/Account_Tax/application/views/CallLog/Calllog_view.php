
        <!-- =============== Left side End ================-->
        <div class="main-content-wrap sidenav-open d-flex flex-column">
            <!-- ============ Body content start ============= -->
            <div class="main-content">
               
                <!-- <div class="separator-breadcrumb border-top"></div> -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="card mb-4">
                            <div class="card-body">
                            <div class="breadcrumb">
                    <h1>Call Log</h1>
                
                </div>
                                <form role="form" id="Form" action="" method="post">
                                    <div class="row">

                                    <div class="col-md-2 form-group mb-3">
                                            <label for="calltype">Call Type</label>
                                            <select class="form-control" name="calltype" id="calltype">
                                                <option value="India">Incoming</option>
                                                <option value="America">Outgoing</option>
                                               
                                            </select>
                                        </div>
                                    

                                        <div class="col-md-3 form-group mb-3">
                                            <label for="callpersonname">Call Person Name</label>
                                            <input class="form-control" id="callpersonname" type="text"  name="callpersonname" value="" />
                                        </div> 
                                        <div class="col-md-2 form-group mb-3">
                                        <label for="calltype">Employee Name</label>
                                            <select class="form-control" name="empname" id="empname">
                                                <option value="India">Sumit</option>
                                                <option value="America">Rutuja</option>
                                                <option value="India">Shravani</option>
                                                <option value="America">Nilambari</option>
                                               
                                            </select>
                                        </div> 
                                        <div class="col-md-2 form-group mb-3">
                                            <label for="calldate">Call Date</label>
                                            <input class="form-control" id="calldate" type="date"   name="calldate" value="" />
                                        </div>
                                        <div class="col-md-3 form-group mb-3">
                                            <label for="callreasontype">Call Reason Type</label>
                                            <select class="form-control" name="reasontype" id="reasontype">
                                                <option value="India">Personal</option>
                                                <option value="America">In Convinience</option>
                                                <option value="India">Friend</option>
                                               
                                               
                                            </select>                                        </div> 
                                        <div class="col-md-2 form-group mb-3">
                                            <label for="calltime">Call Time</label>
                                            <input class="form-control" id="calltime" type="time"  name="calltime" value="" />
                                        </div> 
                                        <div class="col-md-2 form-group mb-3">
                                            <label for="nextfollowdate">Next Follow Date</label>
                                            <input class="form-control" id="nextfollowdate" type="date"  name="nextfollowdate" value="" />
                                        </div> 
                                        <div class="col-md-4 form-group mb-3">
                                            <label for="calldescription">Call Description</label>
                                            <textarea class="form-control" id="calldescription" name="calldescription" rows="4" cols="50"></textarea>

                                            <!-- <input class="form-control" id="calldescription" type="textarea"  name="calldescription" value="" /> -->
                                        </div>  
                                        <div class="col-md-4 form-group mb-3">
                                            <label for="feedback">Feedback</label>
                                            <textarea class="form-control" id="feedback" name="feedback" rows="4" cols="50"></textarea>

                                            <!-- <input class="form-control" id="feedback" type="textarea"  name="feedback" value="" /> -->
                                        </div> 
                                      
                                        


                                        

                                                        
                                        <div class="col-md-12 text-right">
                                    <button class="btn btn-outline-info" type="button" name="btn_save" id="btn_save"><i class="fa-solid fa-check"></i>&nbsp;submit</button>

                                     <a href="<?=base_url() ?>Calllog/index"> <button class="btn btn-outline-warning " type="button" name="edit" id="edit"><i class="fa-solid fa-user-pen"></i>&nbsp;Edit</button></a>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
</div>
                  

<script  src="<?php echo base_url('web_resources');?>/dist/js/jquery.min.js"></script>          
<script  src="<?php echo base_url('web_resources');?>/dist/js/controllers/call_log.js"></script>
                   
                       
<script>
    $('#Form').bind('keydown', function(event) {
    if (event.ctrlKey || event.metaKey) {
    switch (String.fromCharCode(event.which).toLowerCase()) {
    case 's':
    event.preventDefault();
    // alert('ctrl-s');
    saveperform();
    break;

    }
    $(function(){
    $("#district").focus();
    });

    }
    });
</script>             
            