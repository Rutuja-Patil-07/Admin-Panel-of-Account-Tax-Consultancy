<!-- =============== Left side End ================-->
    <div class="main-content-wrap sidenav-open d-flex flex-column">
        <!-- ============ Body content start ============= -->
            <div class="main-content">
                
                <!-- <div class="separator-breadcrumb border-top"></div> -->
                <form role="form" id="Form" action="" method="post">
                    <div class="row">
                        <div class="col-12">
                            <div class="card ">
                                <div class="card-body">
                                <div class="breadcrumb">
                    <h1>Employee</h1>
                    
                </div>
                                    <label class="h4">Personal Information</label>
                                    <br><div class="vh col-12"></div>
                                    <div class="row">
                                        <div class="col-lg-5 col-md-12 col-sm-12 col-xl-5 h6 form-group"><br>
                                            <label>Employee Name<span class="text-danger">*</span></label><br>
                                            <input class="form-control" type="text" name="emp_name" id="emp_name" >
                                        </div>
                                        <div class="col-lg-3 col-md-5 col-sm-12 col-xl-3 h6 form-group"><br>
                                            <label>Primary Mobile<span class="text-danger">*</span></label><br>
                                            <input class="form-control" type="tel" name="mobile" id="mobile" >
                                        </div>
                                        <div class="col-lg-4 col-md-7 col-sm-12 col-xl-4  h6 form-group"><br>
                                            <label>Email<span class="text-danger">*</span></label><br>
                                            <input class="form-control" type="email" name="email" id="email" >
                                        </div>
                                    </div>
                                    <div class=row>
                                         <div class="col-lg-2 col-md-6 col-sm-12 col-xl-2 h6 form-group mb-3">
                                            <label for="picker1">User type</label>
                                            <select class="form-control" name="usertype" id="usertype">
                                                <option value="1">Admin</option>
                                                <option value="2">Reguler User</option>
                                            </select>
                                        </div>
                                        <div class="col-lg-4 col-md-6 col-sm-12 col-xl-4 h6 form-group">
                                            <label>User Name</label>
                                            <input class="form-control" type="text" name="username" id="username" >
                                        </div>
                                        <div class="col-lg-3 col-md-6 col-sm-12 col-xl-3 h6 form-group">
                                            <label>Password</label>
                                            <input class="form-control" type="password" name="password" id="password" >
                                        </div>
                                        <div class="col-lg-3 col-md-6 col-sm-12 col-xl-3 h6 form-group">
                                            <label>Department</label>
                                            <input class="form-control" type="text" name="department" id="department" >
                                        </div>
                                        
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-5 col-md-12 col-sm-12 col-xl-5 h6 form-group">
                                            <label>Address</label>
                                            <textarea class="form-control" type="text" name="address" id="address"></textarea>
                                        </div>
                                        <div class="col-lg-3 col-md-6 col-sm-12 col-xl-3 h6 form-group">
                                            <label>Qualification</label>
                                            <input class="form-control" type="text" name="
                                            qualification" id="qualification" >
                                        </div>
                                        <div class="col-lg-3 col-md-6 col-sm-12 col-xl-3 h6 form-group">
                                            <label>Joining Date</label>
                                            <input class="form-control" type="date" name="joindate" id="joindate" >
                                        </div>

                                    </div>
                                
                                    <div class="row bg-light">
                                     <ul class="nav nav-pills" role="tablist">
                                        <li class="nav-item ">
                                            <a class="nav-link active" data-bs-toggle="pill" href="#details">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20 " fill="currentColor" class="bi bi-person-exclamation" viewBox="0 0 16 16">
                                                <path d="M11 5a3 3 0 1 1-6 0 3 3 0 0 1 6 0ZM8 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4Zm.256 7a4.474 4.474 0 0 1-.229-1.004H3c.001-.246.154-.986.832-1.664C4.484 10.68 5.711 10 8 10c.26 0 .507.009.74.025.226-.341.496-.65.804-.918C9.077 9.038 8.564 9 8 9c-5 0-6 3-6 4s1 1 1 1h5.256Z"/>
                                                <path d="M16 12.5a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0Zm-3.5-2a.5.5 0 0 0-.5.5v1.5a.5.5 0 0 0 1 0V11a.5.5 0 0 0-.5-.5Zm0 4a.5.5 0 1 0 0-1 .5.5 0 0 0 0 1Z"/>
                                                </svg>&nbsp;Personal Details
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" data-bs-toggle="pill" href="#location">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="CurrentColor" class="bi bi-geo-alt-fill" viewBox="0 0 16 16">
                                                <path d="M8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10zm0-7a3 3 0 1 1 0-6 3 3 0 0 1 0 6z"/>
                                                </svg>&nbsp;Location
                                            </a>
                                        </li>
                                        <li class="nav-item nav-item-toggle">
                                            <a class="nav-link" data-bs-toggle="pill" href="#select">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-person-vcard-fill" viewBox="0 0 16 16">
                                                <path d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V4Zm9 1.5a.5.5 0 0 0 .5.5h4a.5.5 0 0 0 0-1h-4a.5.5 0 0 0-.5.5ZM9 8a.5.5 0 0 0 .5.5h4a.5.5 0 0 0 0-1h-4A.5.5 0 0 0 9 8Zm1 2.5a.5.5 0 0 0 .5.5h3a.5.5 0 0 0 0-1h-3a.5.5 0 0 0-.5.5Zm-1 2C9 10.567 7.21 9 5 9c-2.086 0-3.8 1.398-3.984 3.181A1 1 0 0 0 2 13h6.96c.026-.163.04-.33.04-.5ZM7 6a2 2 0 1 0-4 0 2 2 0 0 0 4 0Z"/>
                                                </svg>&nbsp;License Details
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                                    <!-- Tab panes -->
                                    <div class="tab-content">
                                        <div id="details" class="container p-0 tab-pane active">
                                             <br><label class="h5">Other Information</label>
                                    <br><div class="vh col-12"></div>
                                    <div class="row">
                                        <div class="col-lg-2 col-md-2 col-sm-2 col-xl-2 h6 form-group "><br>
                                            <input type="file"  accept="image/gif, image/jpeg, image/png" name="image" id="image" style="display: none;" onchange="loadFile(event)">
                                            <img id="output" width="100" style="border:2px solid; width:100px; height: 120px;" /><br>
                                            <br><label  class="h5 text-primary" for="file" style="cursor: pointer;">Upload Photo</label><br>
                                        </div>
                                        <div class="col-lg-3 col-md-6 col-sm-12 col-xl-3 h6 form-group"><br>
                                            <label>Secondary Mobile<span class="text-danger">*</span></label><br>
                                            <input class="form-control" type="tel" name="smobile" id="smobile">
                                        </div>
                                        <div class="col-lg-2 col-md-6 col-sm-12 col-xl-2 h6 form-group"><br>
                                            <label for="phone">Pincode</label>
                                            <input class="form-control" id="pincode" type="number" maxlength="6" name="pincode" value="" />
                                        </div>&nbsp;&nbsp;&nbsp;
                                        <div class="col-lg-2 col-md-3 col-sm-12 col-xl-2 form-group mb-3"><br>
                                            <label for="picker1">Gender</label>
                                            <div class="d-flex">
                                                <label class="radio radio-primary">
                                                    <input type="gender" name="gender" value="0"><span class="pr-1">Male</span><span class="checkmark"></span>
                                                </label>

                                                <label class="radio radio-primary">
                                                    <input type="gender" name="gender" value="1"><span class="pr-1">Female</span><span class="checkmark"></span>
                                                </label>

                                                <label class="radio radio-primary">
                                                    <input type="gender" name="gender" value="1"><span class="pr-1">Other</span><span class="checkmark"></span>
                                                </label>
                                            </div>
                                        </div>

                                    </div>
                                        </div>
                                        <div id="location" class="container tab-pane fade ">
                                            <br><label class="h5">Other Information</label>
                                            <br><div class="vh col-12"></div>
                                            <br><div class="col-12 h6">Select Your Options:</div>
                                            <div class="row">
                                                 <div class="col-lg-2 col-md-4 col-sm-12 col-xl-2 h6 form-group mb-3">
                                                    <label for="country">Country</label>
                                                    <select class="form-control" name="country" id="country">
                                                        <option value="1">--country--</option>
                                                        <option value="1">India</option>
                                                        <option value="2">Amerika</option>
                                                    </select>
                                                </div>
                                                <div class="col-lg-2 col-md-4 col-sm-12 col-xl-2 h6 form-group mb-3">
                                                    <label for="state">State</label>
                                                    <select class="form-control" name="state" id="state">
                                                        <option value="1">--State--</option>
                                                        <option value="1">Maharastra</option>
                                                        <option value="2">Karnataka</option>
                                                    </select>
                                                </div>
                                                 <div class="col-lg-2 col-md-4 col-sm-12 col-xl-2 h6 form-group mb-3">
                                                    <label for="district">District</label>
                                                    <select class="form-control" name="district" id="district">
                                                        <option value="1">--District--</option>
                                                        <option value="1">Kolhapur</option>
                                                        <option value="2">Pune</option>
                                                    </select>
                                                </div>
                                                 <div class="col-lg-2 col-md-4 col-sm-12 col-xl-2 h6 form-group mb-3">
                                                    <label for="taluka">Taluka</label>
                                                    <select class="form-control" name="taluka" id="taluka">
                                                        <option value="1">--Taluka--</option>
                                                        <option value="1">Radhanagari</option>
                                                        <option value="2">Kagal</option>
                                                    </select>
                                                </div> 
                                                <div class="col-lg-2 col-md-4 col-sm-12 col-xl-2 h6 form-group mb-3">
                                                   <label for="village">Village</label>
                                                   <select class="form-control" name="village" id="village" >
                                                       <option value="1">--Village--</option>
                                                       <option value="1">Walva Bk</option>
                                                       <option value="2">Bidri</option>
                                                   </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="select" class="container tab-pane fade">
                                             <br><label class="h5">Other Information</label>
                                            <br><div class="vh col-12"></div><br>
                                            <div class="row">
                                                <div class="col-lg-3 col-md-5 col-sm-12 col-xl-3 h6 form-group mb-3">
                                                    <label for="district">Licence Info</label>
                                                    <select class="form-control" name="lic_info" id="lic_info">
                                                        <option value="1">--Licence--</option>
                                                        <option value="1">1</option>
                                                        <option value="2">2</option>
                                                    </select>
                                                </div>
                                                <div class="col-lg-3 col-md-7 col-sm-12 col-xl-3 h6 form-group">
                                                    <label>Licence No</label>
                                                    <input class="form-control" type="number" name="licence_no" id="licence_no" >
                                                </div>
                                                <div class="col-lg-3 col-md-6 col-sm-12 col-xl-3 form-group ">
                                                    <label for="job">Start Date</label>
                                                    <input class="form-control" id="startdate" type="date"  name="startdate" value="" />
                                                 </div>
                                                 <div class="col-lg-3 col-md-6 col-sm-12 col-xl-3 form-group ">
                                                    <label for="job">Expiry Date</label>
                                                    <input class="form-control" id="expirydate" type="date"  name="expirydate" value="" />
                                                 </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-lg-4 col-md-12 col-sm-12 col-xl-4 h6 form-group">
                                                    <label>Warning before expiry</label>
                                                    <input class="form-control" type="text" name="warning" id="warning" >
                                                </div>
                                            </div>
                                             <div class="row">
                                                <div class="col-lg-2 col-md-4 col-sm-3 col-xl-2 h6 form-group ">
                                                    <button class="form-control btn add" id="addlist" name="addlist" >
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-card-list" viewBox="0 0 16 16">
                                                        <path d="M14.5 3a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-13a.5.5 0 0 1-.5-.5v-9a.5.5 0 0 1 .5-.5h13zm-13-1A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h13a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-13z"/>
                                                        <path d="M5 8a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7A.5.5 0 0 1 5 8zm0-2.5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5zm0 5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5zm-1-5a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0zM4 8a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0zm0 2.5a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0z"/>
                                                        </svg>&nbsp;&nbsp;Add To List</button>
                                                </div>
                                            </div>
                                            <br>
                                            <div class="row">
                                                <span class="text-danger h5">Licence Details</span>
                                                <div class="col-12">
                                                    <div class="card-body">
                                                        <div class="table-responsive">
                                                            <table class="display table table-striped table-bordered" id="example" style="width:100%">
                                                                <thead>
                                                                <tr>
                                                                    <th>Operation</th>
                                                                    <th>Licence Id</th>
                                                                    <th>Licence Info</th>
                                                                    <th>Licence No</th>
                                                                    <th>Start Date</th>
                                                                    <th>Expiry Date</th>
                                                                    <th>Warning Beforeb xpiry</th>
                                                                </tr>
                                                                </thead>
                                                            </table>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                     </div>
                                     <div class="col-md-12 text-right ">
                                     <button class="btn btn-outline-info" type="button" name="btn_save" id="btn_save"><i class="fa-solid fa-check"></i>&nbsp;submit</button>
                                     <a href="<?=base_url() ?>Employee/index"> <button class="btn btn-outline-warning " type="button" name="edit" id="edit"><i class="fa-solid fa-user-pen"></i>&nbsp;Edit</button></a>
                                      </div>

                                </div>
                                
                            </div>
                              
                        </div>

                    </form>
                </div>

   


                  
<script>
var loadFile = function(event) {
    var image = document.getElementById('output');
    image.src = URL.createObjectURL(event.target.files[0]);
};
</script>
<script  src="<?php echo base_url('web_resources');?>/dist/js/jquery.min.js"></script>          
<script  src="<?php echo base_url('web_resources');?>/dist/js/controllers/employee.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
                   
                       
               
            