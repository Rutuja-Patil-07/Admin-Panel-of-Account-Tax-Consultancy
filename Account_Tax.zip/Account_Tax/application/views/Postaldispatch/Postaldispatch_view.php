
        <!-- =============== Left side End ================-->
        <div class="main-content-wrap sidenav-open d-flex flex-column">
            <!-- ============ Body content start ============= -->
            <div class="main-content">
                
                <!-- <div class="separator-breadcrumb border-top"></div> -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="card mb-4">
                       
                            <div class="card-body">
                            <div class="breadcrumb">
                    <h1>Postal Dispatch</h1>
                   
                </div>
                            <h2><u>Outward Letter Transaction Information</u></h2>

                                <form role="form" id="Form" action="" method="post">
                                    <div class="row mt-3">
                                        <div class="col-md-2 form-group mb-3">
                                            <label for="outwordno">Outword no.*</label>
                                            <input class="form-control" id="outwordno" type="number"  name="outwordno" value="" />
                                        </div>
                                        <div class="col-md-2 form-group mb-3">
                                            <label for="outwordletterno">Outword Letter no.*</label>
                                            <input class="form-control" id="outwordletterno" type="number" name="outwordletterno" value="" />
                                        </div>

                                        <div class="col-md-2 form-group mb-3">
                                            <label for="outworddate">Outword date</label>
                                            <input class="form-control" id="outworddate" type="date"  name="outworddate" value="" />
                                        </div>

                                    </div>
                                    <h2 class="mt-3"><u>To Whom correspondence</u></h2>
                                    <div class="row">
                                    <div class="col-md-3 form-group mb-3">
                                            <label for="name">Name</label>
                                            <input class="form-control" id="name" type="text"  name="name" value="" />
                                        </div>
                                        <div class="col-md-3 form-group mb-3">
                                            <label for="name">Place.*</label>
                                            <select class="form-control" name="Place" id="Place">
                                                <option value="A">kolhapur</option>
                                                <option value="B">Sangali</option>
                                                <option value="AB">Satara</option>
                                                <option value="O">Pune</option>

                                            </select> 
                                         </div>
                                        <div class="col-md-4 form-group mb-3">
                                            <label for="firstName1">Address</label>
                                            <textarea class="form-control" rows="2" id="address" name="address"></textarea>

                                        </div>
                                        <div class="col-md-2 form-group mb-3">
                                            <label for="name">Incoming Number for Reference</label>
                                            <input class="form-control" id="no_ref" type="number"  name="no_ref" value="" />
                                        </div>
                                     </div> 
                                     <div class="row">
                                   
                                        <div class="col-md-2 form-group mb-3">
                                            <label for="name">Incoming Date for Reference</label>
                                            <input class="form-control" id="date_ref" type="date"  name="date_ref" value="" />
                                        </div>
                                        <div class="col-md-4 form-group mb-3">
                                            <label for="firstName1">The subject of Correspondence.*</label>
                                            <textarea class="form-control" rows="3" id="subject"  name="subject"></textarea>

                                        </div>
                                        <div class="col-md-4 form-group mb-3 mt-2">
                                            <label for="firstName1">Remark</label>
                                            <textarea class="form-control" rows="2" id="remark"  name="remark"></textarea>

                                        </div>
                                        <div class="col-md-2 form-group mb-3 mt-2">
                                            <label for="firstName1">Postal charges</label>
                                            <input class="form-control" id="charges" type="number"  name="charges" value="" />
                                        </div>
                                     </div> 
                                     <div class="row">
                                     
                                     </div> 
                                     <div class="col-md-12 text-right">
                                     <button class="btn btn-outline-info" type="button" name="btn_save" id="btn_save"><i class="fa-solid fa-check"></i>&nbsp;submit</button>

                                     <a href="<?=base_url() ?>Postaldispatch/index"> <button class="btn btn-outline-warning " type="button" name="edit" id="edit"><i class="fa-solid fa-user-pen"></i>&nbsp;Edit</button></a>
                                        </div>
                                </form>
                            </div>
                        </div>
                </div>
</div>
                  

<script  src="<?php echo base_url('web_resources');?>/dist/js/jquery.min.js"></script>          
<script  src="<?php echo base_url('web_resources');?>/dist/js/controllers/postal_dispatch.js"></script>
                   
<script>
     var date = new Date();
var day = date.getDate();
var month = date.getMonth() + 1;
var year = date.getFullYear();

if (month < 10) month = "0" + month;
if (day < 10) day = "0" + day;

var today = year + "-" + month + "-" + day;       
document.getElementById("date1").value = today;
document.getElementById("date2").value = today;

</script>                       
               
            