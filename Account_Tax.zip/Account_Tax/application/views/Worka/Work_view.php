
        <!-- =============== Left side End ================-->
        <div class="main-content-wrap sidenav-open d-flex flex-column">
            <!-- ============ Body content start ============= -->
            <div class="main-content">
                
                <!-- <div class="separator-breadcrumb border-top"></div> -->
                <div class="row">
                    <div class="col-md-12">
                    <div class="card mb-4">
                            <div class="card-body">
                    <div class="breadcrumb">
                    <h1> Work Allocation</h1>
                   
                </div>
                                <form role="form" id="Form" action="" method="post">
                                    <div class="row">
                                    <div class="col-4 form-group mb-3">
                                            <label for="picker1">Expected Name</label>
                                            <select class="form-control" name="subject">
                                            <option>--Expected Name--</option>    
                                            <option value="1">asdf</option>
                                                <option value="2">kjh</option>
                                                <option value="3">jkhi</option>
                                            </select>
                                        </div>
                                        <div class=" col-4 form-group mb-3">
                                            <label for="time">Expected time</label>
                                            <input class="form-control" id="time" type="time" name="time" value="<?php echo date('H-m-s'); ?>" />
                                        </div>
                                        
                                    </div>
                                    <div class="row">
                                    <div class="col-4 form-group mb-3">
                                            <label for="desc">Work</label>
                                            <textarea class="form-control" name="description" id="desc" cols="" rows="2" placeholder="Enter description"></textarea> 
                                    </div>
                                    <div class=" col-4 form-group mb-3">
                                            <label for="date">Expected Date</label>
                                            <input class="form-control" id="date" type="date" name="date" value="<?php echo date('Y-m-d'); ?>" />
                                    </div>
                                    </div>
                                    <div class="row">
                                    <div class="col-4 form-group mb-3">
                                            <label for="desc">Description</label>
                                            <textarea class="form-control" name="description" id="desc" cols="" rows="" placeholder="Enter description"></textarea> 
                                    </div>
                                    <div class="col-4 form-group mb-3">
                                            <label for="picker1">Task Assigned to</label>
                                            <select class="form-control" name="subject">
                                            <option>--Task Assigned to--</option>    
                                            <option value="1">asdf</option>
                                                <option value="2">kjh</option>
                                                <option value="3">jkhi</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="row">
                                    <div class="col-4 form-group mb-3">
                                            <label for="desc">Status</label>
                                            <textarea class="form-control" name="description" id="desc" cols="" rows="" placeholder="Enter description"></textarea> 
                                    </div>
                                    <div class="col-4 form-group mb-3">
                                            <label for="desc">Remark</label>
                                            <textarea class="form-control" name="description" id="desc" cols="" rows="" placeholder="Enter description"></textarea> 
                                    </div>
                                    </div>
                                    
                                    
                                       
                                   
                                    <div class="col-md-12 text-right">
                                    <button class="btn btn-outline-info" type="button" name="btn_save" id="btn_save"><i class="fa-solid fa-check"></i>&nbsp;submit</button>

                                     <a href="<?=base_url() ?>"> <button class="btn btn-outline-warning " type="button" name="edit" id="edit"><i class="fa-solid fa-user-pen"></i>&nbsp;Edit</button></a>
                                        </div>
                                </form>
                    </div>
</div>
                  

<script  src="<?php echo base_url('web_resources');?>/dist/js/jquery.min.js"></script>          
<script  src="<?php echo base_url('web_resources');?>/dist/js/controllers/CountryCreate.js"></script>
                   
</html>                       
               
            