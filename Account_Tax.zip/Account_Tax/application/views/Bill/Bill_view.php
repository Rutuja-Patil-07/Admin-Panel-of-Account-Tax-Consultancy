<style type="text/css">
    .text{
  border: none;border-bottom: 1px solid; border-radius: 0px;
}
.box{
    border: 2px solid;
}

</style>
<!-- =============== Left side End ================-->
    <div class="main-content-wrap sidenav-open d-flex flex-column">
        <!-- ============ Body content start ============= -->
            <div class="main-content">
                
                <!-- <div class="separator-breadcrumb border-top"></div> -->
                <form role="form" id="Form" action="" method="post">
                    <div class="row">
                        <div class="col-12">
                            <div class="card p-3 pt-0" id="printme">
                                <div class="box p-3">
                                <div class="card-body">
                                    
                                    <div class="h1">D.D.ASSOCIATES</div>   
                                    <div class="row">
                                        <div class="col-lg-5 col-md-5 col-sm-12 col-xl-5">
                                        <p>
                                            NINAD A.DAKWE<br>
                                            M.Com, D.B.M, G.D.C. & A., D.T.L., D.C.A, B.Ed<br>
                                            United Classic,203,2nd Floor,<br>
                                            Bazarpeth,Chiplun,Dist.Ratnagiri

                                        </p>
                                        </div>
                                        <div class="col-lg-3 col-md-3 col-sm-12 col-xl-3"><br>
                                        <label class="bg-dark text-white p-2 h1"> RECEIPT</label>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-12 col-xl-4">
                                        <label>No.</label>&nbsp;&nbsp;<input type="number" name="billno" id="billno"><br>
                                        <label>Date</label>&nbsp;&nbsp;<input type="date" name="date" id="date">
                                        </div>
                                    </div>
                                     <div class="row">     
                                        <div class="col-lg-3 col-md-4 col-sm-3 col-xl-3"><br>
                                            Received with thanks from
                                             </div>
                                            <div class="col-lg-9 col-md-9 col-sm-12 col-xl-9">
                                                <input class="form-control text"  type="text" name="text" id="text" >
                                            </div>
                                       </div>
                                       <div class="row">
                                            <div class="col-lg-12 col-md-12 col-sm-12 col-xl-12">
                                                <input class=" form-control text" type="text" name="text" id="text" >
                                            </div>
                                        </div>
                                        <div class="row">

                                            <div class="col-lg-2 col-md-3 col-sm-2 col-xl-2"><br>
                                                The sum of Rupees
                                            </div>
                                             <div class="col-lg-10 col-md-9 col-sm-12 col-xl-10">
                                                <input class="text form-control" type="text" name="text" id="text" >
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-12 col-md-12 col-sm-12 col-xl-12">
                                                <input class="text form-control" type="text" name="text" id="text" >
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-9 col-md-8 col-sm-9 col-xl-9">
                                                <input class="text form-control" type="text" name="text" id="text" >
                                            </div>
                                        
                                            <div class="col-lg-3 col-md-4 col-sm-3 col-xl-3"><br>
                                                By Draft/Cash in Part/Full/Advence
                                            </div>

                                        </div>
                                        <div class="row">
                                            <div class="col-lg-3 col-md-4 col-sm-3 col-xl-3"><br>
                                                Payment on A/C our Bill No.
                                            </div>
                                            <div class="col-lg-3 col-md-5 col-sm-3 col-xl-3">
                                                <input class="text form-control" type="text" name="text" id="text">
                                            </div>
                                            <div class="col-lg-1 col-md-3 col-sm-1 col-xl-1"><br>
                                                <label>Dated</label>
                                            </div>
                                            <div class="col-lg-5 col-md-9 col-sm-5 col-xl-5">
                                                <input class="text form-control" type="text" name="text" id="text">
                                            </div>
                                        </div>
                                    </div><br>
                                    <div class="row">
                                        <div class="col-lg-2 col-md-4 col-sm-12 col-xl-3">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-currency-rupee" viewBox="0 0 16 16">
                                            <path d="M4 3.06h2.726c1.22 0 2.12.575 2.325 1.724H4v1.051h5.051C8.855 7.001 8 7.558 6.788 7.558H4v1.317L8.437 14h2.11L6.095 8.884h.855c2.316-.018 3.465-1.476 3.688-3.049H12V4.784h-1.345c-.08-.778-.357-1.335-.793-1.732H12V2H4v1.06Z"/>
                                            </svg>
                                            <input type="number" name="payment" id="payment"><br>Cheque Receipt Subject to Realisation
                                        </div>
                                         <div class="col-lg-6 col-md-6 col-sm-6 col-xl-6 h6 form-group ">
                                         </div>
                                        <div class="col-lg-2 col-md-2 col-sm-2 col-xl-2 h6 form-group ">
                                            <input type="file"  accept="image/gif, image/jpeg, image/png" name="image" id="file" style="display: none;" onchange="loadFile(event)">
                                            <img id="output" width="100" style="border:1px solid; width:120px; height: 30px;" /><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            <label  class="h3" for="file" style="cursor: pointer;">Sign</label><br>
                                        </div>
                                    </div>

                                </div>
                                    
                               

                                </div>
                                </div>
                            </div>
                              
                       <div class="col-md-12 text-right ">
                        <button class="btn btn-outline-info " type="button" name="print" id="print" onclick="myprint('printme')">Print</button>
                        <a href="<?=base_url() ?>Employee"> <button class="btn btn-outline-warning " type="button" name="cancle" id="cancle">Cancel</button></a>

                    </form>
                     
                    </div>
                </div>
            </div>
        </div>


   


                  
<script>
var loadFile = function(event) {
    var image = document.getElementById('output');
    image.src = URL.createObjectURL(event.target.files[0]);
};
</script>
<script  src="<?php echo base_url('web_resources');?>/dist/js/jquery.min.js"></script>          
<script  src="<?php echo base_url('web_resources');?>/dist/js/controllers/StudentCreate.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
   

<script type="text/javascript">
    function myprint(printme){
        var printdata= document.getElementById(printme);
        newin=window.open("");
        newin.document.write(printdata.outerHTML);
        newin.print();
        newin.close();

    }
</script>  

               
            