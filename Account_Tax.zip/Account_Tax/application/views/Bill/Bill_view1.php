<style type="text/css">
    .text{
  border: none;border-bottom: 1px solid; border-radius: 0px;
}
.box{
    border: 2px solid;
}



</style>
<!-- =============== Left side End ================-->
    <div class="main-content-wrap sidenav-open d-flex flex-column">
        <!-- ============ Body content start ============= -->
            <div class="main-content">
                
                <!-- <div class="separator-breadcrumb border-top"></div> -->
                <form role="form" id="Form" action="" method="post">
                    <div class="row">
                        <div class="col-12">
                            <div class="card p-3 pt-0" id="printme">
                                <div class="card-body">
                                <div class="box p-3">
                                    <div class="row">
                                        <div class="col-lg-5 col-md-5 col-sm-12 col-xl-5">
                                        <p>
                                            <h2><b>Priti Ninad Dakve</b></h2>
                                            M.Com, G.D.C., D.C.A. & A. <br>
                                            Professional Accountant &<br>
                                            Investment Consultant & Insurance Advisor

                                        </p>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-12 col-xl-4">                                        
                                        </div>
                                        <div class="col-lg-3 col-md-3 col-sm-12 col-xl-3 h4"><br>
                                            (O) (02355) 261280<br>
                                            Mobile:9422631298
                                        </div>
                                    </div>
                                     <div class="row">     
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xl-12 h2 text-center">
                                            Swami Shradha, 2nd Floor, Markandi, Chiplun, Dist. Ratnagiri
                                       </div>
                                    </div>
                                    </div><br>
                                       <div class="row">
                                            <div class="col-lg-1 col-md-1 col-sm-1 col-xl-1 h5"><br>M/S.</div>
                                            <div class="col-lg-8 col-md-8 col-sm-8 col-xl-8">
                                                <input class=" form-control text" type="text" name="text" id="text" >
                                            </div>
                                            <div class="col-lg-1 col-md-1 col-sm-1 col-xl-1 h5">
                                            <br>Bill.No</div>
                                            <div class="col-lg-2 col-md-2 col-sm-2 col-xl- h5">
                                                <input  class="form-control" type="number" name="billno" id="billno" >
                                            </div>
                                        </div>
                                        <div class="row">
                                           
                                            <div class="col-lg-9 col-md-9 col-sm-9 col-xl-9">
                                                <input class=" form-control text" type="text" name="text" id="text" >
                                            </div>
                                            <div class="col-lg-1 col-md-1 col-sm-1 col-xl-1 h5">
                                            <br>Date</div>
                                            <div class="col-lg-2 col-md-2 col-sm-2 col-xl- h5">
                                                <input  class="form-control" type="date" name="date" id="date" >
                                            </div>
                                        </div>
                                        <div class="table-responsive p-4 box">
                                            <table class="display table  table-bordered" id="example" style="width:100%">
                                            <thead>
                                                <tr class="h5 bg-light">
                                                    <th class="col-8">Particuler</th>
                                                    <th class="col-4">Amount</th>
                                                    
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr class="h5">
                                                    <td class="col-8">1) Account Writing Fees</td>
                                                    <td class="col-4"><input class=" form-control text" type="number" name="fee1" id="fee1" ></td>
                                                    
                                                </tr>
                                                <tr class="h5">
                                                    <td class="col-8">2) Account Writing Fees</td>
                                                    <td class="col-4"><input class=" form-control text" type="number" name="fee2" id="fee2" ></td>
                                                    
                                                </tr>
                                                <tr class="h5">
                                                    <td class="col-8">3) Account Writing Fees</td>
                                                    <td class="col-4"><input class=" form-control text" type="number" name="fee3" id="fee3" ></td>
                                                    
                                                </tr>
                                                <tr class="h5">
                                                    <td class="col-8">4) Account Writing Fees</td>
                                                    <td class="col-4"><input class=" form-control text" type="number" name="fee4" id="fee4" ></td>
                                                    
                                                </tr>
                                                <tr class="h5">
                                                    <td class="col-8">5) Account Writing Fees</td>
                                                    <td class="col-4"><input class=" form-control text" type="number" name="fee5" id="fee5" ></td>
                                                    
                                                </tr>
                                                <tr class="h5">
                                                    <td class="col-8">6) Account Writing Fees</td>
                                                    <td class="col-4"><input class=" form-control text" type="number" name="fee6" id="fee6" ></td>
                                                    
                                                </tr>
                                                <tr class="h5">
                                                    <td class="col-8">7) Account Writing Fees</td>
                                                    <td class="col-4"><input class=" form-control text" type="number" name="fee7" id="fee7" ></td>
                                                    
                                                </tr>
                                                <tr class="h5">
                                                    <td class="col-8">8) Account Writing Fees</td>
                                                    <td class="col-4"><input class=" form-control text" type="number" name="fee8" id="fee8" ></td>
                                                    
                                                </tr>
                                                <tr class="h5">
                                                    <td class="col-8">9) Account Writing Fees</td>
                                                    <td class="col-4"><input class=" form-control text" type="number" name="fee9" id="fee9" ></td>
                                                    
                                                </tr>
                                                <tr class="h5">
                                                    <td class="col-8">10) Account Writing Fees</td>
                                                    <td class="col-4"><input class=" form-control text" type="number" name="fee10" id="fee10" ></td>
                                                    
                                                </tr>
                                                <tr class="h5">
                                                    <td class="col-8 text-right h5"><b>Total</b></td>
                                                    <td class="col-4"><input class=" form-control text" type="number" name="fee1" id="fee1" ></td>
                                                    
                                                </tr>
                                                
                                           </tbody>
                                        </table>
                                        <div class="row">
                                            <div class="col-lg-1 col-md-1 col-sm-1 col-xl-1 h5">Rs.</div>
                                            <div class="col-lg-9 col-md-9 col-sm-9 col-xl-9">
                                                <input class=" form-control text" type="text" name="text" id="text" >
                                            </div>
                                            <div class="col-lg-2 col-md-2 col-sm-2 col-xl- h4 text-center">
                                                        For P.N. Dakve
                                            </div>
                                        </div>
                                       
                                        <div class="row">
                                                       
                                                        <div class="col-lg-10 col-md-10 col-sm-10 col-xl-10">
                                                        <input class=" form-control text" type="text" name="text" id="text" >
                                                        </div>
                                                        <div class="col-lg-2 col-md-2 col-sm-2 col-xl- h4 text-center"><br>
                                                        Proprietor
                                                        </div>
                                        </div>
                                                </div>
                                    </div>

                                </div>
                                    
                               

                                </div>
                                </div>
                            
                              
                       <div class="col-md-12 text-right ">
                        <button class="btn btn-outline-info " type="button" name="print" id="print" onclick="myprint('printme')">Print</button>
                        <a href="<?=base_url() ?>Employee"> <button class="btn btn-outline-warning " type="button" name="cancle" id="cancle">Cancel</button></a>

                    </form>
                     
                    </div>
                </div>
            </div>
        </div>


   


                  
<script>
var loadFile = function(event) {
    var image = document.getElementById('output');
    image.src = URL.createObjectURL(event.target.files[0]);
};
</script>
<script  src="<?php echo base_url('web_resources');?>/dist/js/jquery.min.js"></script>          
<script  src="<?php echo base_url('web_resources');?>/dist/js/controllers/StudentCreate.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
   
                       
  <script type="text/javascript">
    function myprint(printme){
        var printdata= document.getElementById(printme);
        newin=window.open("");
        newin.document.write(printdata.outerHTML);
        newin.print();
        newin.close();

    }
</script>  
             
            