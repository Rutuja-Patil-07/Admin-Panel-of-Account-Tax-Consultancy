<link rel="stylesheet" href="https://cdn.datatables.net/1.13.1/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.3.2/css/buttons.dataTables.min.css">
<!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.0/css/bootstrap.min.css"> -->
  <!-- <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" /> -->
<link rel="stylesheet" href="Assets/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.1/css/dataTables.bootstrap3.min.css">
<style>
body{
	font-family:"Trebuchet MS", "Myriad Pro", Arial, sans-serif;
	font-size:14px;
	background:#f4f4f4 url("Assets/images/img15.webp") ;
    background-size: 100%;
	color:#333;
	text-shadow:1px 1px 1px #fff;
	
}
.form-container{
   
    display: flex;
    justify-content: center;
    height: 100px;
    left: 550px;
    top: -50px;
    opacity: 2.5;

}

.form-box{
    display: flex;
    flex-direction: column;
    justify-content: center;
    min-height: 100vh;
    /* opacity: 0.5; */
}

.form-box h4{
    font-weight: bold;
    color: rgb(12, 9, 12);
}

.form-box .form-input {
    position: relative;
}

.form-box .form-input input{
    width: 100%;
    height: 50px;
    margin-bottom: 20px;
    border: none;
    border-radius: 5px;
    outline: none;
    background: white;
    padding-left: 45px;
}

.form-box .form-input span{
    position: absolute;
    top: 8px;
    padding-left: 20px;
    color: #777;
}

.form-box .form-input input::placeholder{
    padding-left: 0px;
}

.form-box .form-input input:focus,
.form-box .form-input input:valid{
    border-bottom: 2px solid #dc3545;
}

.form-box input[type="checkbox"]:not(:checked) + label:before{
    background: transparent;
    border: 2px solid #fff;
    width: 15px;
    height: 15px;
}

.form-box .custom-checkbox .custom-control-input:checked ~ .custom-control-label::before{
    background-color: rgb(18, 17, 18);
    border: 0px;
}

.form-box button[type="submit"]{
    border: none;
    cursor: pointer;
    width: 150px;
    height: 40px;
    border-radius: 5px;
    background-color: #fff;
    color: #000;
    font-weight: bold;
    transition: 0.5s;
}

.form-box button[type="submit"]:hover{
    -webkit-box-shadow: 0px 9px 10px -2px rgba(0,0,0,0.55);
    -moz-box-shadow: 0px 9px 10px -2px rgba(0,0,0,0.55);
    box-shadow: 0px 9px 10px -2px rgba(0,0,0,0.55);
}
.custom-control-label{
    color: rgb(11, 10, 11);
    font-weight: bold;

}
.forget-link, .register-link, .login-link{
    color: rgb(14, 13, 13);
    font-weight: bold;
}
.class {
    color: rgb(11, 11, 11);
    font-weight: bold;  
}
.forget-link:hover, .register-link:hover, .login-link:hover{
    color: #292525;
}

.form-box .btn-social{
    color: #fff;
    border: 0;
    margin-bottom: 10px;
}

.form-box .btn-facebook{
    background: #4866a8;
}

.form-box .btn-google{
    background: #da3f34
}

.form-box .btn-twitter{
    background: #33ccff;
}

.form-box .btn-facebook:hover{
    color: #fff;
    background: #3d5785;
}

.form-box .btn-google:hover{
    background: #bf3b31;
    color: #fff;
}

.form-box .btn-twitter:hover{
    background: #2eb7e5;
    color: #fff;
}
    </style>


<body>
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-6 col-md-6 form-container">
				<div class="col-lg-8 col-md-12 col-sm-9 col-xs-12 form-box">
					<div class="logo mt-5 mb-3 text-center">
						<img src="Assets/images/img15.svg" width="150px">
					</div>
					<div class="reset-form d-block">
						<form class="reset-password-form">
							<h4 class="mb-3">Reset Your Password</h4>
							<p class="class mb-3">
								<h4>Please enter your mobile number and we will send you an OTP.</h4>
							</p>
							<div class="form-input">
								<span><i class="fa fa-phone fa-2x "></i></span>
								<input type="number" placeholder="&emsp;Mobile Number" required>
							</div>
							<div class="mb-3">
								<button type="submit" class="btn">Send OTP</button>
							</div>
						</form>
					</div>
					<div class="reset-confirmation d-none">
						<div class="mb-4">
							<h4 class="mb-3">OTP was sent</h4>
							<h6 class="class">Please, check your Message</h6>
						</div>
						<div>
							<a href="login.html">
								<button type="submit" class="btn">Login Now</button>
							</a>
						</div>
					</div>
				</div>
			</div>

			<div class="col-lg-6 col-md-6 d-none d-md-block image-container"></div>
		</div>
	</div>

	<script type="text/javascript">
		function PasswordReset() {
			$('form.reset-password-form').on('submit', function(e){
				e.preventDefault();
				$('.reset-form')
				.removeClass('d-block')
				.addClass('d-none');
				$('.reset-confirmation').addClass('d-block');
			});
		}

		window.addEventListener('load',function(){
			PasswordReset();
		});
	</script>
</body>
