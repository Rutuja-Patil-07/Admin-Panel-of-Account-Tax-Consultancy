
        <!-- =============== Left side End ================-->
        <div class="main-content-wrap sidenav-open d-flex flex-column">
            <!-- ============ Body content start ============= -->
            <div class="main-content">
                
                <!-- <div class="separator-breadcrumb border-top"></div> -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="card mb-4">
                            <div class="card-body">
                            <div class="breadcrumb">
                    <h1>Attendence Summery</h1>
                </div>
                </div>

                                <form role="form" id="Form" action="" method="post">
                                    <div class="row">
                                       
                                        
                                      
                                    <div class="col-md-2 form-group mb-3">
                                        <label for="attendence">From Date:</label>
                                        <input type="date" class="form-control" id="attendence" placeholder="Enter AttendenceDate..." name="attendence" value="<?php echo date('Y-m-d'); ?>">                                    
                                    </div>

                                     

                                    <div class="col-md-1 mt-4 mb-3 text-right">
                                       <button class="btn btn-success" type="button" name="btn_search" id="btn_search"><i class="nav-icon fa-regular fa-circle-check"></i> Search</button>
                                    </div>&emsp;&emsp;&emsp;&emsp;
                                    </div>

                                   

                                    <div class="col-md-12 text-right">
                                     <a href="<?=base_url() ?>"> <button class="btn btn-outline-info" type="button" name="submit" id="submit"><i class="fa-solid fa-check"></i>&nbsp;submit</button></a>

                                     <a href="<?=base_url() ?>"> <button class="btn btn-outline-warning " type="button" name="edit" id="edit"><i class="fa-solid fa-user-pen"></i>&nbsp;Edit</button></a>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
</div>
                  

<script  src="<?php echo base_url('web_resources');?>/dist/js/jquery.min.js"></script>          
<script  src="<?php echo base_url('web_resources');?>/dist/js/controllers/Familytypecreate.js"></script>
                   
                       
               
            