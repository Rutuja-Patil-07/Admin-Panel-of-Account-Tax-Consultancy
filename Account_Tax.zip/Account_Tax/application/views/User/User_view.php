<!-- =============== Left side End ================-->
    <div class="main-content-wrap sidenav-open d-flex flex-column">
        <!-- ============ Body content start ============= -->
            <div class="main-content">
               
                <!-- <div class="separator-breadcrumb border-top"></div> -->
                <form role="form" id="Form" action="" method="post">
                    <div class="row">
                        <div class="col-12">
                            <div class="card ">
                                <div class="card-body">
                                <div class="breadcrumb">
                    <h1>User</h1>
                   
                </div>
                                    
                                    <div class=row>
                                         <div class="col-lg-2 col-md-6 col-sm-12 col-xl-2 h6 form-group mb-3">
                                            <label for="picker1">Employee</label>
                                            <select class="form-control" name="usertype" id="usertype">
                                                <option value="Sumit">Sumit</option>
                                                <option value="Nilambari">Nilambari</option>
                                                <option value="Rutuja">Rutuja</option>
                                                <option value="Shravani">Shravani</option>
                                            </select>
                                        </div>
                                    </div>
                                            
                                            <br>
                                            <div class="row">
                                                
                                                <div class="col-12">
                                                    <div class="card-body">
                                                        <div class="table-responsive">
                                                            <table class="display table table-striped table-bordered" id="example" style="width:100%">
                                                                <thead>
                                                                <tr>
                                                                    <th>Action</th>
                                                                    <th>Form Name</th>
                                                                    <th>Control Name</th>
                                                                    
                                                                </tr>
                                                                </thead>
                                                                <tbody>   
                                                                    <tr>
                                                                        <td><input type="checkbox" id="check" name="check"></td>
                                                                        <td>New Employee</td>
                                                                        <td><a href="<?=base_url('Employee/create');?>" data-mdb-toggle="tooltip" title="edit">&nbsp;Employee/create</a></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td><input type="checkbox" id="check" name="check"></td>
                                                                        <td>New Attendence</td>
                                                                        <td><a href="<?=base_url('CreateAttendence/create');?>" data-mdb-toggle="tooltip" title="edit">&nbsp;Attendence/create</a></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td><input type="checkbox" id="check" name="check"></td>
                                                                        <td>Work Allocation</td>
                                                                        <td><a href="<?=base_url('Project/create');?>" data-mdb-toggle="tooltip" title="edit">&nbsp;Work_Allocation/create</a></td>
                                                                    </tr>
                                                                    <tr>
                                                                    <td><input type="checkbox" id="check" name="check"></td>
                                                                        <td>Document Master</td>
                                                                        <td><a href="<?=base_url('Document/create');?>" data-mdb-toggle="tooltip" title="edit">&nbsp;Document/create</a></td>
                                                                    </tr>
                                                                    <tr>
                                                                    <td><input type="checkbox" id="check" name="check"></td>
                                                                        <td>Master</td>
                                                                        <td><a href="<?=base_url('Country/create');?>" data-mdb-toggle="tooltip" title="edit">&nbsp;Master/create</a></td>
                                                                    </tr>
                                                                    <tr>
                                                                    <td><input type="checkbox" id="check" name="check"></td>
                                                                        <td>Call & Postal</td>
                                                                        <td><a href="<?=base_url('CallLog/create');?>" data-mdb-toggle="tooltip" title="edit">&nbsp;CallLog/create</a></td>
                                                                    </tr>
                                                                </tbody>                
                                                            </table>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-12 text-right">
                                     <button class="btn btn-outline-info" type="button" name="btn_save" id="btn_save"><i class="fa-solid fa-check"></i>&nbsp;submit</button>

                                     <a href="<?=base_url() ?>User"> <button class="btn btn-outline-warning " type="button" name="edit" id="edit"><i class="fa-solid fa-user-pen"></i>&nbsp;Edit</button></a>
                                        </div>
                                        </div>
                                        
                                     </div>
                                     

                                </div>
                                
                            </div>
                              
                        </div>

                    </form>
                </div>
</div>
   


                  
<script>
var loadFile = function(event) {
    var image = document.getElementById('output');
    image.src = URL.createObjectURL(event.target.files[0]);
};
</script>
<script  src="<?php echo base_url('web_resources');?>/dist/js/jquery.min.js"></script>          
<script  src="<?php echo base_url('web_resources');?>/dist/js/controllers/StudentCreate.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
                   
                       
               
            