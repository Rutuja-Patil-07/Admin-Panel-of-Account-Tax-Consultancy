
<!-- =============== Left side End ================-->
    <div class="main-content-wrap sidenav-open d-flex flex-column">
        <!-- ============ Body content start ============= -->
            <div class="main-content">
                
                <!-- <div class="separator-breadcrumb border-top"></div> -->
                <form role="form" id="Form" action="" method="post">
                    <div class="row">
                        <div class="col-12">
                            <div class="card p-3 ">
                                <div class="card-body">
                                <div class="breadcrumb">
                    <h1>Create </h1>
                                    </div>
                                    <label class="h4">Customer Information</label>
                                    <br><div class="vh col-12"></div><br>
                                    <div class=row>
                                         <div class="col-lg-4 col-md-6 col-sm-12 col-xl-4 h6 form-group mb-3">
                                            <label for="picker1">Name Of Client</label>
                                            <select class="form-control" name="usertype" id="usertype">
                                                <option value="1"></option>
                                                <option value="2"></option>
                                            </select>
                                        </div>
                                        <div class="col-lg-4 col-md-6 col-sm-12 col-xl-4 h6 form-group">
                                            <label>Date</label>
                                            <input class="form-control" type="Date" name="date" id="date" >
                                        </div>
                                        <div class="col-lg-4 col-md-6 col-sm-12 col-xl-4 h6 form-group">
                                            <label>Mobile No.</label>
                                            <input class="form-control" type="tel" name="mobile" id="mobile" >
                                        </div>
                                        
                                        
                                    </div>
                                    <div class=row>
                                         <div class="col-lg-4 col-md-6 col-sm-12 col-xl-4 h6 form-group mb-3">
                                            <label for="picker1">Type Of Client</label>
                                            <select class="form-control" name="usertype" id="usertype">
                                                <option value="1"></option>
                                                <option value="2"></option>
                                            </select>
                                        </div>
                                        <div class="col-lg-4 col-md-6 col-sm-12 col-xl-4 h6 form-group mb-3">
                                            <label for="picker1">F.Y</label>
                                            <select class="form-control" name="usertype" id="usertype">
                                                <option value="1"></option>
                                                <option value="2"></option>
                                            </select>
                                        </div>
                                        <div class="col-lg-4 col-md-6 col-sm-12 col-xl-4 h6 form-group">
                                            <label>Date of Reply</label>
                                            <input class="form-control" type="Date" name="date" id="date" >

                                        </div>
                                        
                                        
                                    </div>  
                                    
                                    <div>
                                        <label class="h4">Required Document</label>
                                        <br><div class="vh col-12"></div><br>
                                        
                                        <div class="row">
                                           
                                            <div class="col-lg-2 col-md-2 col-sm-12 col-xl-2 h6">
                                                <label for="picker1">Document number</label>
                                                <select class="form-control" name="usertype" id="usertype">
                                                    <option value="1"></option>
                                                    <option value="2"></option>
                                                </select>
                                            </div>
                                            <div class="col-lg-2 col-md-2 col-sm-12 col-xl-2 h6">
                                                <label for="picker1">Document Label</label><input class="form-control" type="text" name="doclabel" id="doclabel">
                                            </div>
                                            <div class="col-lg-2 col-md-2 col-sm-12 col-xl-2 h6">
                                                <label for="picker1">Scan Copy</label><input class="form-control" type="file" name="document1" id="document1">
                                            </div>
                                            <div class="col-lg-2 col-md-2 col-sm-12 col-xl-2 h6">
                                                <label for="picker1">Date</label><input class="form-control" type="date" name="date" id="date">
                                            </div>
                                            <div class="col-lg-2 col-md-2 col-sm-12 col-xl-2 h6">
                                                <label for="picker1">Status</label>
                                                <select class="form-control" name="usertype" id="usertype">
                                                    <option value="1"></option>
                                                    <option value="2"></option>
                                                </select>
                                            </div>
                                        
                                        </div> 
                                          
                                    </div>
                                     <div class="col-md-12 text-right ">
                                     <button class="btn btn-outline-info " type="button" name="btn_save" id="btn_save">Submit</button>
                                     <a href="<?=base_url() ?>Employee"> <button class="btn btn-outline-warning " type="button" name="cancle" id="cancle">Edit</button></a>
                                      </div>

                                      <br><div class="vh col-12"></div><br>
                                      <a href="<?=base_url() ?>"><button class="btn btn-outline-success" style="float:right;"><i class="fa-solid fa-plus"></i>&nbsp;Add To List</button></a>
                                <div class="table-responsive p-2">

                                    <table class="display table table-striped table-bordered" id="example" style="width:100%">
                                        <thead>
                                            <tr>
                                                <th>Action</th>
                                                <th>Client Name</th>
                                                <th>Date</th>
                                                <th>Mobile No</th>
                                                <th>Type of Client</th>
                                                <th>Financial Year</th> 
                                                <th>Document number</th>
                                                <th>Document Label</th> 
                                                <th>Scan Copy</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                            <tr id="row1">
                                                <td>
                                                <button class="delete " onclick="delete_row('1')" style="border:none">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="red" class="bi bi-trash" viewBox="0 0 16 16">
                                                <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"/>
                                                <path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/>
                                                </svg>
                                                </button></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                            <tr id="row2">
                                                <td>
                                                <button class="delete " onclick="delete_row('2')" style="border:none">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="red" class="bi bi-trash" viewBox="0 0 16 16">
                                                <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"/>
                                                <path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/>
                                                </svg>
                                                </button></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                            </tr>     
                                        </tbody>    
                                    </table>
                                </div>

                                </div>
                                
                            </div>
                              
                        </div>
                    </div>

                    </form>
                </div>

   


                  

<script  src="<?php echo base_url(); ?>web_resources/dist/js/jquery.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>

<script>
    function delete_row(no) {
 document.getElementById("row" + no + "").outerHTML = "";
}
</script>
<script  src="<?php echo base_url(); ?>web_resources/dist/js/jquery.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>

    <script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script type="text/javascript" src=https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js></script> 
<script type="text/javascript" src="https://cdn.datatables.net/buttons/2.3.2/js/dataTables.buttons.min.js"></script>
 <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script> 
 <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script> 
 <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script> 
 <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.3.2/js/buttons.html5.min.js"></script> 
 <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.3.2/js/buttons.print.min.js"></script>
<script>
$(document).ready(function() {
    $('#example').DataTable( { 
            
         responsive: true,
         dom: 'Bfrtip',
         dom: 'lBfrtip',
         buttons: [
            { extend: 'copy',text:'<img src="https://img.icons8.com/color/2x/copyright--v1.png" style="width:25px;">', className: 'buttons-copy' },
           { extend: 'csv',text: '<img src="https://img.icons8.com/color/2x/csv.png" style="width:25px;">', className: 'buttons-csv' },
           { extend: 'excel',text: '<img src="https://img.icons8.com/color/512/ms-excel.png" style="width:25px;">', className: 'buttons-excel' },
           { extend: 'pdf',text: '<img src="https://img.icons8.com/color/512/pdf-2--v1.png" style="width:25px;">', className: 'buttons-pdf' },
           { extend: 'print',text: '<img src="https://img.icons8.com/3d-fluency/2x/print.png" style="width:25px;">', className: 'buttons-print' }
                ],
            initComplete: function() {
            var btns = $('.dt-button');
            btns.removeClass('dt-button');
        },
        
    } );
    
} );
</script>
                   
                       
               
            
