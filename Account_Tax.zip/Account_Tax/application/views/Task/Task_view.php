<!-- =============== Left side End ================-->
    <div class="main-content-wrap sidenav-open d-flex flex-column">
        <!-- ============ Body content start ============= -->
            <div class="main-content">
                <div class="breadcrumb">
                    <h1>Task </h1>
                    <!-- <ul>
                        <li><a href="href.html">Form</a></li>
                        <li>Basic</li>
                    </ul> -->
                </div>
                <div class="separator-breadcrumb border-top"></div>
                <form role="form" id="Form" action="" method="post">
                    <div class="row">
                        <div class="col-12">
                            <div class="card p-3">
                                <div class="card-body">
                                    
                                    <label class="h4">Task</label>
                                    <br><div class="vh col-12"></div>
                                    <div class="row">
                                        <div class="col-5 h6 form-group"><br>
                                            <label>Task Name<span class="text-danger">*</span></label><br>
                                            <input class="form-control" type="text" name="taskname" id="taskname" >
                                        </div>
                                        <div class="col-3 h6 form-group"><br>
                                            <label>Group Name</label><br>
                                            <input class="form-control" type="text" name="groupname" id="groupname" >
                                        </div>
                                        <div class="col-4 h6 form-group"><br>
                                            <label>Project Name<span class="text-danger">*</span></label><br>
                                            <input class="form-control" type="text" name="projectname" id="projectname" >
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-12 h6 form-group">
                                            <label>Employee Name<span class="text-danger">*</span></label><br>
                                            <input class="form-control" type="text" name="emp_name" id="Emp_name" >
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-4 h6 form-group">
                                            <label>Work Hours<span class="text-danger">*</span></label><br>
                                            <input class="form-control" type="text" name="emp_name" id="emp_name" >
                                        </div>
                                        <div class="col-5 h6 form-group">
                                            <label>Description</label><br>
                                            <textarea class="form-control" type="tel" name="mobile" id="mobile" rows="2"></textarea>
                                        </div>
                                        
                                    </div>
                                    <div class="row">
                                        <div class="col-md-2 form-group mb-3">
                                            <label for="job">Start Date</label>
                                            <input class="form-control" id="startdate" type="date"  name="startdate" value="" />
                                        </div>
                                        <div class="col-md-2 form-group mb-3">
                                            <label for="job">Due Date</label>
                                            <input class="form-control" id="duedate" type="date"  name="duedate" value="" />
                                        </div>
                                        <div class="col-md-2 form-group mb-3"><br>
                                            <label for="job">Standard Flexible Flag</label>&nbsp;&nbsp;
                                            <input  id="check1" type="checkbox"  name="check1" value="" />
                                        </div>
                                        <div class="col-md-5 form-group mb-3"><br>
                                            <label for="job">Reuses Task:</label>&nbsp;&nbsp;
                                            <input  id="check2" type="checkbox"  name="check2" value="" />
                                            <label for="job">reuses Task</label>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4 h6 form-group mb-3">
                                            <label for="taluka">Task List Type Name</label>
                                            <select class="form-control" name="taluka" id="taluka">
                                                <option value="0">--Task List Type Name--</option>
                                                <option value="1"></option>
                                                <option value="2"></option>
                                            </select>
                                        </div>
                                        <div class="col-md-4 h6 form-group mb-3">
                                            <label for="taluka">Work Hours Type Name</label>
                                            <select class="form-control" name="taluka" id="taluka">
                                                <option value="0">--Work Hours Type Name--</option>
                                                <option value="1"></option>
                                                <option value="2"></option>
                                            </select>
                                        </div>
                                        <div class="col-md-4 h6 form-group mb-3">
                                            <label for="taluka">Reminder Type Name</label>
                                            <select class="form-control" name="taluka" id="taluka">
                                                <option value="0">--Reminder Type Name--</option>
                                                <option value="1"></option>
                                                <option value="2"></option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4 h6 form-group mb-3">
                                            <label for="taluka">Priority Name</label>
                                            <select class="form-control" name="taluka" id="taluka">
                                                <option value="0">--Priority Name--</option>
                                                <option value="1"></option>
                                                <option value="2"></option>
                                            </select>
                                        </div>
                                        <div class="col-md-4 h6 form-group mb-3">
                                            <label for="taluka">Billing Type Name</label>
                                            <select class="form-control" name="taluka" id="taluka">
                                                <option value="0">--Billing Type Name--</option>
                                                <option value="1"></option>
                                                <option value="2"></option>
                                            </select>
                                        </div>
                                        <div class="col-md-4 h6 form-group mb-3">
                                            <label for="taluka">Status Name</label>
                                            <select class="form-control" name="taluka" id="taluka">
                                                <option value="0">--Status Name--</option>
                                                <option value="1"></option>
                                                <option value="2"></option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-2 h6 form-group mb-3">
                                            <input type="file"  accept="image/gif, image/jpeg, image/png" name="image" id="file" style="display: none;" onchange="loadFile(event)">
                                            <label  class="h5" >Document 1</label><br>
                                            <img id="output" width="100" style="border:2px solid; width:100px; height: 120px;" />
                                            <br><label  class="h5 text-primary" for="file" style="cursor: pointer;">Upload Document</label><br>
                                        </div>
                                        <div class="col-md-2 h6 form-group mb-3">
                                            <input type="file"  accept="image/gif, image/jpeg, image/png" name="image" id="file" style="display: none;" onchange="loadFile(event)">
                                             <label  class="h5" >Document 2</label><br>
                                            <img id="output" width="100" style="border:2px solid; width:100px; height: 120px;" />
                                            <br><label  class="h5 text-primary" for="file" style="cursor: pointer;">Upload Document</label><br>
                                        </div>
                                        <div class="col-md-2 h6 form-group mb-3">
                                            <input type="file"  accept="image/gif, image/jpeg, image/png" name="image" id="file" style="display: none;" onchange="loadFile(event)">
                                            <label  class="h5" >Document 3</label><br>
                                            <img id="output" width="100" style="border:2px solid; width:100px; height: 120px;" />
                                            <br><label  class="h5 text-primary" for="file" style="cursor: pointer;">Upload Document</label><br>
                                        </div>
                                        <div class="col-md-2 h6 form-group mb-3">
                                            <input type="file"  accept="image/gif, image/jpeg, image/png" name="image" id="file" style="display: none;" onchange="loadFile(event)">
                                             <label  class="h5" >Document 4</label><br>
                                            <img id="output" width="100" style="border:2px solid; width:100px; height: 120px;" />
                                            <br><label  class="h5 text-primary" for="file" style="cursor: pointer;">Upload Document</label><br>
                                        </div>
                                        <div class="col-md-2 h6 form-group mb-3">
                                            <input type="file"  accept="image/gif, image/jpeg, image/png" name="image" id="file" style="display: none;" onchange="loadFile(event)">
                                             <label  class="h5" >Document 5</label><br>
                                            <img id="output" width="100" style="border:2px solid; width:100px; height: 120px;" />
                                            <br><label  class="h5 text-primary" for="file" style="cursor: pointer;">Upload Document</label><br>
                                        </div>
                                    </div>
                                    <div class="col-md-12 text-right">
                                     <a href="<?=base_url() ?>"> <button class="btn btn-outline-info" type="button" name="submit" id="submit"><i class="fa-solid fa-check"></i>&nbsp;submit</button></a>

                                     <a href="<?=base_url() ?>Task/index"> <button class="btn btn-outline-warning " type="button" name="edit" id="edit"><i class="fa-solid fa-user-pen"></i>&nbsp;Edit</button></a>
                                        </div>
                                </div>
                            </div>  
                        </div>
                    </form>
                </div>

   


                  
<script>
var loadFile = function(event) {
    var image = document.getElementById('output');
    image.src = URL.createObjectURL(event.target.files[0]);
};
</script>
<script  src="<?php echo base_url('web_resources');?>/dist/js/jquery.min.js"></script>          
<script  src="<?php echo base_url('web_resources');?>/dist/js/controllers/StudentCreate.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
                   
                       
               
            