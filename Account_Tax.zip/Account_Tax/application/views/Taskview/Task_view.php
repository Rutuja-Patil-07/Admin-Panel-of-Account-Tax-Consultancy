
        <!-- =============== Left side End ================-->
        <div class="main-content-wrap sidenav-open d-flex flex-column">
            <!-- ============ Body content start ============= -->
            <div class="main-content">
                
                <!-- <div class="separator-breadcrumb border-top"></div> -->
                <!-- <div class="vh col-12 bg-light mb-4"></div> -->
                <div class="row">
                        <div class="col-md-12">
                        <div class="card mb-4">
                            <div class="card-body">
                        <div class="breadcrumb">
                    <h1>Task Creation</h1>
                    
                </div>
                                <form role="form" id="Form" action="" method="post">
                                    <div class="row">
                                        <div class="col-4  form-group mb-3">
                                            <label for="taskName">Task Name</label>
                                            <input class="form-control" id="taskname" type="text" placeholder="Enter your task name" name="taskname" value="" />
                                        </div>
                                        <div class="col-4 form-group mb-3">
                                            <label for="picker1">Group Name</label>
                                            <select class="form-control" name="subject">
                                            <option>--Group Name--</option>    
                                            <option value="1">asdf</option>
                                                <option value="2">kjh</option>
                                                <option value="3">jkhi</option>
                                            </select>
                                        </div>
                                        <div class="col-4 form-group mb-3">
                                            <label for="picker1">Project Name</label>
                                            <select class="form-control" name="subject">
                                               
                                            <option>--Project Name--</option>
                                            <option value="1">English</option>
                                                <option value="2">Marathi</option>
                                                <option value="3">Hindi</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="row">
                                    <div class="col-4 form-group mb-3">
                                            <label for="Name">Employee Name</label>
                                            <input class="form-control" type="text" id="empname" name="empname" value="" />
                                        </div>
                                        <div class="col-4 form-group mb-3">
                                            <label for="workhour">Work Hours</label>
                                            <input class="form-control" id="workhour" type="text" placeholder="Enter work hours" name="workhour" value="" />
                                        </div>
                                        <div class="col-4 form-group mb-3">
                                            <label for="desc">Description</label>
                                            <textarea class="form-control" name="description" id="desc" cols="" rows=""></textarea> 
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        <div class=" col-4 form-group mb-3">
                                            <label for="date"> Start Date</label>
                                            <input class="form-control" id="date" type="date" name="date" value="<?php echo date('Y-m-d'); ?>" />
                                        </div>
                                        <div class=" col-4 form-group mb-3">
                                            <label for="date">Due Date</label>
                                            <input class="form-control" id="date" type="date" name="date" value="<?php echo date('Y-m-d'); ?>" />
                                        </div>
                                        <div class="col-2 form-group mt-4">
                                            <label for="name">Standard Flexible Flag:
                                                <input type="checkbox" name="flag" id="flag" checked>

                                            </label>
                                        </div>
                                        <div class="col-2 form-group mt-4">
                                            <label for="name">Reuses Task:
                                                <input type="checkbox" name="flag" id="flag" checked>

                                            </label>
                                        </div>
                                    </div>
                                
                                    <div class="row mt-3 ">
                                    <div class="vh col-12 bg-light mb-4"></div>
                                        <div class="col-4 form-group mb-3">
                                            <label for="picker1">Task List Type Name</label>
                                            <select class="form-control" name="tasklisttype">
                                               <option>--Task List Type Name--</option>
                                            <option value="1">type1</option>
                                                <option value="2">type1</option>
                                                <option value="3">type1</option>
                                            </select>
                                        </div>

                                        <div class="col-4 form-group mb-3">
                                            <label for="picker1">Work Hours Type Name</label>
                                            <select class="form-control" name="workhourtype">
                                            <option>--Work Hours Type Name--</option>
                                                <option value="1">type1</option>
                                                <option value="2">type1</option>
                                                <option value="3">type1</option>
                                            </select>
                                        </div>
                                     
                                        <div class="col-4 form-group mb-3">
                                            <label for="picker1">Reminder Type name</label>
                                            <select class="form-control" name="remindertype">
                                            <option>--Reminder Type name--</option>
                                            <option value="1">type1</option>
                                                <option value="2">type1</option>
                                                <option value="3">type1</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-4 form-group mb-3">
                                            <label for="picker1">Priority Name</label>
                                            <select class="form-control" name="priority" id="priority">
                                            <option>--Priority Name--</option>
                                            <option value="1">type1</option>
                                                <option value="2">type1</option>
                                                <option value="3">type1</option>
                                            </select>
                                        </div>

                                        <div class="col-4 form-group mb-3">
                                            <label for="picker1">Billing Type Name</label>
                                            <select class="form-control" name="department" id="department">
                                            <option>--Billing Type Name--</option>
                                            <option value="1">type1</option>
                                                <option value="2">type1</option>
                                                <option value="3">type1</option>
                                            </select>
                                        </div>

                                        <div class="col-4 form-group mb-3">
                                            <label for="picker1">Status Name</label>
                                            <select class="form-control" name="status" id="status">
                                                <option>--Status Name--</option>
                                                <option value="1">type1</option>
                                                <option value="2">type1</option>
                                                <option value="3">type1</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-4 form-group mb-3">
                                        <label for="file" style="cursor: pointer;">Document 1</label>
                                        <img id="output" width="100">
                                        <input type="file"  accept="image1/*" class="form-control" name="output" id="output"  onchange="loadFile(event)">
                                        </div>
                                        
                                        <div class="col-4 form-group mb-3">
                                        <label for="file" style="cursor: pointer;">Document 2</label>
                                        <img id="output1" width="100">
                                        <input type="file"  accept="image2/*" class="form-control" name="output1" id="output1"  onchange="loadFile1()">

                                        </div>
                                        <div class="col-4 form-group mb-3">
                                        <label for="file" style="cursor: pointer;">Document 3</label>
                                        <img id="output2" width="100">
                                        <input type="file"  accept="image3/*" class="form-control" name="output2" id="output2"  onchange="loadFile2()">

                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-4 form-group mb-3">
                                        <label for="file" style="cursor: pointer;">Document 4</label>
                                        <img id="output3" width="100">
                                        <input type="file"  accept="image4/*" class="form-control" name="output3" id="output3"  onchange="loadFile3()">
                                        </div>
                                        <div class="col-4 form-group mb-3">
                                        <label for="file" style="cursor: pointer;">Document 5</label>
                                        <img id="output4" width="100">
                                        <input type="file"  accept="image5/*" class="form-control" name="output4" id="output4"  onchange="loadFile4()">
                                        </div>
                                        
                                    </div>
                                    <div class="col-md-12 text-right">
                                    <button class="btn btn-outline-info" type="button" name="btn_save" id="btn_save"><i class="fa-solid fa-check"></i>&nbsp;submit</button>

                                     <a href="<?=base_url() ?>Taskview/index"> <button class="btn btn-outline-warning " type="button" name="edit" id="edit"><i class="fa-solid fa-user-pen"></i>&nbsp;Edit</button></a>
                                        </div>
                                    
                                </form>
                                <!-- <div class="vh col-12 bg-light mt-4"></div> -->
                        </div>
                        </div>
                        </div>
                        </div>
                  

<script  src="<?php echo base_url('web_resources');?>/dist/js/jquery.min.js"></script>          
<script  src="<?php echo base_url('web_resources');?>/dist/js/controllers/StudentCreate.js"></script>
 
<script>
                        var loadFile = function(event) {
	                    var image1 = document.getElementById('output');
                       
	                    image1.src = URL.createObjectURL(event.target.files[0]);
                        }
                        
                        var loadFile1= function() {
	                    var image2 = document.getElementById('output1');
                       
	                    image2.src = URL.createObjectURL(event.target.files[0]);
                        }
                        var loadFile2 = function() {
	                    var image3 = document.getElementById('output2');
                       
	                    image3.src = URL.createObjectURL(event.target.files[0]);
                        }
                        var loadFile3 = function() {
	                    var image4 = document.getElementById('output3');
                       
	                    image4.src = URL.createObjectURL(event.target.files[0]);
                        }
                        var loadFile4 = function() {
	                    var image5 = document.getElementById('output4');
                       
	                    image5.src = URL.createObjectURL(event.target.files[0]);
                        }
                    </script>                  
                       
               
             
