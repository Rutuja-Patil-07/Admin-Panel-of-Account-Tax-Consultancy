
        <!-- =============== Left side End ================-->
        <div class="main-content-wrap sidenav-open d-flex flex-column">
            <!-- ============ Body content start ============= -->
            <div class="main-content">
                
                <!-- <div class="separator-breadcrumb border-top"></div> -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="card mb-4">
                            <div class="card-body">
                            <div class="breadcrumb">
                    <h1>Village</h1>
                
                </div>
                                <form role="form" id="Form" action="" method="post">
                                    <div class="row">

                              
                                      
                                        <div class="col-md-3 form-group mb-3">
                                            <label for="picker1">Country</label>
                                            <select class="form-control" name="country" id="country">
                                                <option value="India">India</option>
                                                <option value="America">America</option>
                                                <option value="China">China</option>
                                              
                                            </select>
                                        </div>


                                        <div class="col-md-3 form-group mb-3">
                                            <label for="picker1">State</label>
                                            <select class="form-control" name="state" id="state">
                                                <option value="Maharashtra">Maharashtra</option>
                                                <option value="Amaravati">Amaravati</option>
                                                <option value="Assam">Assam</option>
                                                <option value="Gujarat">Gujarat</option>
                                                <option value="Goa">Goa</option>
                                                <option value="Kerala">Kerala</option>
                                                <option value="Rajasthan">Rajasthan</option>
                                                <option value="Tamil Nadu">Tamil Nadu</option>

                                              
                                            </select>
                                        </div>

                                        <div class="col-md-3 form-group mb-3">
                                            <label for="picker1">District</label>
                                            <select class="form-control" name="district" id="district">
                                                <option value="Sangli">Sangli</option>
                                                <option value="Kohapur">Kohapur</option>
                                                <option value="Pune">Pune</option>
                                                <option value="Satara">Satara</option>                                              
                                            </select>
                                        </div>
                                        
                                        <div class="col-md-3 form-group mb-3">
                                            <label for="picker1">Taluka</label>
                                            <select class="form-control" name="taluka" id="taluka">
                                                <option value="Walawa">Walawa</option>
                                                <option value="Shirala">Shirala</option>
                                                <option value="Palus">Palus</option>
                                                <option value="Karad">Karad</option>                                              
                                            </select>
                                        </div>


                                        <div class="col-md-3 form-group mb-3">
                                            <label for="firstName1">Village name</label>
                                            <input class="form-control" id="village_name" type="text" name="village_name" value="" />
                                        </div>
                                                    
                                        <div class="col-md-12 text-right">
                                     <button class="btn btn-outline-info" type="button" name="btn_save" id="btn_save"><i class="fa-solid fa-check"></i>&nbsp;submit</button>

                                     <a href="<?=base_url() ?>Village/index"> <button class="btn btn-outline-warning " type="button" name="edit" id="edit"><i class="fa-solid fa-user-pen"></i>&nbsp;Edit</button></a>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
</div>
                  

<script  src="<?php echo base_url('web_resources');?>/dist/js/jquery.min.js"></script>          
<script  src="<?php echo base_url('web_resources');?>/dist/js/controllers/village.js"></script>
                   

<script>
    $('#Form').bind('keydown', function(event) {
    if (event.ctrlKey || event.metaKey) {
    switch (String.fromCharCode(event.which).toLowerCase()) {
    case 's':
    event.preventDefault();
    // alert('ctrl-s');
    saveperform();
    break;

    }
    $(function(){
    $("#village").focus();
    });

    }
    });
</script>
                       
              
            