
        <!-- =============== Left side End ================-->
        <div class="main-content-wrap sidenav-open d-flex flex-column">
            <!-- ============ Body content start ============= -->
            <div class="main-content">
                
                <!-- <div class="separator-breadcrumb border-top"></div> -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="card mb-4">
                            <div class="card-body">
                            <div class="breadcrumb">
                    <h1>Work details</h1>
                    </div>
                     <a href="<?=base_url() ?>Work/create"><button class="btn btn-outline-success" style="float:right;"><i class="fa-solid fa-plus"></i>&nbsp;Add Work</button></a>

                        
                   
                        
              
                                <div class="table-responsive">
                                <table class="display table table-striped table-bordered" id="example" style="width:100%">
                                        <thead>
                                            <tr class="bg-light">
                                                <th>Action</th>
                                                <th>Employee Name</th>
                                                <th>Work Start Date</th>
                                                <th>Work End Date</th>
                                                <th>Work Start Time</th>
                                                <th>Work End Time</th> 
                                                <th>Status</th>
                                                <th>Work Assigned to</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr id="row1">
                                                 <td><i class="far fa-edit fa-lg"style="color:#1977D3;"></i><a href="<?=base_url('Employee/create');?>" data-mdb-toggle="tooltip" title="edit">&nbsp;Edit</a></td>
                                                <td>Python</td>
                                                <td>Python</td>
                                                <td>Py</td>
                                                <td>Development</td>
                                                <td>20/01/2023</td>
                                                <td>20/01/2023</td>
                                                <td>20/01/2023</td>
                                            </tr>  
                                            <tr id="row2">
                                                 <td><i class="far fa-edit fa-lg"style="color:#1977D3;"></i><a href="<?=base_url('Employee/create');?>" data-mdb-toggle="tooltip" title="edit">&nbsp;Edit</a></td>
                                                <td>Python</td>
                                                <td>Python</td>
                                                <td>Py</td>
                                                <td>Development</td>
                                                <td>20/01/2023</td>
                                                <td>20/01/2023</td>
                                                <td>20/01/2023</td>
                                            </tr>     
                                            <tr id="row3">
                                                 <td><i class="far fa-edit fa-lg"style="color:#1977D3;"></i><a href="<?=base_url('Employee/create');?>" data-mdb-toggle="tooltip" title="edit">&nbsp;Edit</a></td>
                                                <td>Python</td>
                                                <td>Python</td>
                                                <td>Py</td>
                                                <td>Development</td>
                                                <td>20/01/2023</td>
                                                <td>20/01/2023</td>
                                                <td>20/01/2023</td>
                                            </tr>  
                                            <tr id="row4">
                                                 <td><i class="far fa-edit fa-lg"style="color:#1977D3;"></i><a href="<?=base_url('Employee/create');?>" data-mdb-toggle="tooltip" title="edit">&nbsp;Edit</a></td>
                                                <td>Python</td>
                                                <td>Python</td>
                                                <td>Py</td>
                                                <td>Development</td>
                                                <td>20/01/2023</td>
                                                <td>20/01/2023</td>
                                                <td>20/01/2023</td>
                                            </tr>  
                                            <tr id="row5">
                                                 <td><i class="far fa-edit fa-lg"style="color:#1977D3;"></i><a href="<?=base_url('Employee/create');?>" data-mdb-toggle="tooltip" title="edit">&nbsp;Edit</a></td>
                                                <td>Python</td>
                                                <td>Python</td>
                                                <td>Py</td>
                                                <td>Development</td>
                                                <td>20/01/2023</td>
                                                <td>20/01/2023</td>
                                                <td>20/01/2023</td>
                                            </tr>  
                                            <tr id="row6">
                                                 <td><i class="far fa-edit fa-lg"style="color:#1977D3;"></i><a href="<?=base_url('Employee/create');?>" data-mdb-toggle="tooltip" title="edit">&nbsp;Edit</a></td>
                                                <td>Python</td>
                                                <td>Python</td>
                                                <td>Py</td>
                                                <td>Development</td>
                                                <td>20/01/2023</td>
                                                <td>20/01/2023</td>
                                                <td>20/01/2023</td>
                                            </tr>  
                                        </tbody>    
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
</div>
                  

<script  src="<?php echo base_url(); ?>web_resources/dist/js/jquery.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>

    <script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script type="text/javascript" src=https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js></script> 
<script type="text/javascript" src="https://cdn.datatables.net/buttons/2.3.2/js/dataTables.buttons.min.js"></script>
 <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script> 
 <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script> 
 <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script> 
 <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.3.2/js/buttons.html5.min.js"></script> 
 <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.3.2/js/buttons.print.min.js"></script>
<script>
$(document).ready(function() {
    $('#example').DataTable( { 
            
         responsive: true,
         dom: 'Bfrtip',
         dom: 'lBfrtip',
         buttons: [
           { extend: 'copy',text:'<img src="https://img.icons8.com/color/2x/copyright--v1.png" style="width:25px;">', className: 'buttons-copy' },
           { extend: 'csv',text: '<img src="https://img.icons8.com/color/2x/csv.png" style="width:25px;">', className: 'buttons-csv' },
           { extend: 'excel',text: '<img src="https://img.icons8.com/color/512/ms-excel.png" style="width:25px;">', className: 'buttons-excel' },
           { extend: 'pdf',text: '<img src="https://img.icons8.com/color/512/pdf-2--v1.png" style="width:25px;">', className: 'buttons-pdf' },
           { extend: 'print',text: '<img src="https://img.icons8.com/3d-fluency/2x/print.png" style="width:25px;">', className: 'buttons-print' }
                ],
            initComplete: function() {
            var btns = $('.dt-buttons');
            btns.removeClass('dt-buttons');
        },
        
    } );
    
    
} );






</script>